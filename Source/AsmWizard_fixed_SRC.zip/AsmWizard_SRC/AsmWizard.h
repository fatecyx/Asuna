#if !defined(AFX_ASMWIZARD_H__36600690_91A8_4F55_908C_6F2FBDB44AEE__INCLUDED_)
#define AFX_ASMWIZARD_H__36600690_91A8_4F55_908C_6F2FBDB44AEE__INCLUDED_

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

// TODO: You may add any other custom AppWizard-wide declarations here.


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ASMWIZARD_H__36600690_91A8_4F55_908C_6F2FBDB44AEE__INCLUDED_)
