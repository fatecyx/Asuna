// cstm1dlg.cpp : implementation file
//

#include "stdafx.h"
#include "AsmWizard.h"
#include "cstm1dlg.h"
#include "AsmWizardaw.h"


#ifdef _PSEUDO_DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCustom1Dlg dialog

CCustom1Dlg::CCustom1Dlg()
	: CAppWizStepDlg(CCustom1Dlg::IDD)
{
	//{{AFX_DATA_INIT(CCustom1Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CCustom1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CAppWizStepDlg::DoDataExchange(pDX);
    
	//{{AFX_DATA_MAP(CCustom1Dlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

// This is called whenever the user presses Next, Back, or Finish with this step
//  present.  Do all validation & data exchange from the dialog in this function.
BOOL CCustom1Dlg::OnDismiss()
{
	if (!UpdateData(TRUE))
		return FALSE;

	// TODO: Set template variables based on the dialog's data.

	return TRUE;	// return FALSE if the dialog shouldn't be dismissed
}


BEGIN_MESSAGE_MAP(CCustom1Dlg, CAppWizStepDlg)
	//{{AFX_MSG_MAP(CCustom1Dlg)
	ON_BN_CLICKED(IDC_CONSOLE, OnConsole)
	ON_BN_CLICKED(IDC_DYNAMIC, OnDynamic)
	ON_BN_CLICKED(IDC_WINDOWS, OnWindows)
	ON_BN_CLICKED(IDC_STATIC_LIB, OnStaticLib)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CCustom1Dlg message handlers

void CCustom1Dlg::OnConsole() 
{
	switch (AsmWizardaw.m_ProjectType)
	{
	case 2:
		AsmWizardaw.m_Dictionary.RemoveKey("PROJTYPE_DLL");
		break;
	case 3:
		AsmWizardaw.m_Dictionary.RemoveKey("PROJTYPE_LIB");
		break;
	}

	AsmWizardaw.m_Dictionary.SetAt("PROJTYPE_CON", "1");

    AsmWizardaw.SetProjectType(1);
}

void CCustom1Dlg::OnDynamic() 
{
	switch (AsmWizardaw.m_ProjectType)
	{
	case 1:
		AsmWizardaw.m_Dictionary.RemoveKey("PROJTYPE_CON");
		break;
	case 3:
		AsmWizardaw.m_Dictionary.RemoveKey("PROJTYPE_LIB");
		break;
	}

	AsmWizardaw.m_Dictionary.SetAt("PROJTYPE_DLL", "1");

    AsmWizardaw.SetProjectType(2);
}

void CCustom1Dlg::OnWindows() 
{
	switch (AsmWizardaw.m_ProjectType)
	{
	case 1:
		AsmWizardaw.m_Dictionary.RemoveKey("PROJTYPE_CON");
		break;
	case 2:
		AsmWizardaw.m_Dictionary.RemoveKey("PROJTYPE_DLL");		
		break;
	case 3:
		AsmWizardaw.m_Dictionary.RemoveKey("PROJTYPE_LIB");
		break;
	}

    AsmWizardaw.SetProjectType(0);
}

void CCustom1Dlg::OnStaticLib() 
{
	switch(AsmWizardaw.m_ProjectType)
	{
	case 1:
		AsmWizardaw.m_Dictionary.RemoveKey("PROJTYPE_CON");
		break;
	case 2:
		AsmWizardaw.m_Dictionary.RemoveKey("PROJTYPE_DLL");
		break;
	}

	AsmWizardaw.m_Dictionary.SetAt("PROJTYPE_LIB", "1");

    AsmWizardaw.SetProjectType(3);
}

BOOL CCustom1Dlg::OnInitDialog() 
{
	CAppWizStepDlg::OnInitDialog();

	// Ĭ��ѡ��  Windows Application
    ((CButton*)GetDlgItem(IDC_WINDOWS))->SetCheck(BST_CHECKED);

    // ����λͼ����ʾ.
    bmpLoad.LoadBitmap(IDB_BITMAP1);
    ((CStatic*)GetDlgItem(IDC_STATIC_IMAGE))->SetBitmap(HBITMAP(bmpLoad.Detach()));

	return TRUE;
}
