// AsmWizardaw.cpp : implementation file
//

#include "stdafx.h"
#include "AsmWizard.h"
#include "AsmWizardaw.h"
#include "chooser.h"

#ifdef _PSEUDO_DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// This is called immediately after the custom AppWizard is loaded.  Initialize
//  the state of the custom AppWizard here.
void CAsmWizardAppWiz::InitCustomAppWiz()
{
	// Create a new dialog chooser; CDialogChooser's constructor initializes
	//  its internal array with pointers to the steps.
	m_pChooser = new CDialogChooser;

	// Set the maximum number of steps.
	SetNumberOfSteps(LAST_DLG);

	// TODO: Add any other custom AppWizard-wide initialization here.
}

// This is called just before the custom AppWizard is unloaded.
void CAsmWizardAppWiz::ExitCustomAppWiz()
{
	// Deallocate memory used for the dialog chooser
	ASSERT(m_pChooser != NULL);
	delete m_pChooser;
	m_pChooser = NULL;

	// TODO: Add code here to deallocate resources used by the custom AppWizard
}

// This is called when the user clicks "Create..." on the New Project dialog
//  or "Next" on one of the custom AppWizard's steps.
CAppWizStepDlg* CAsmWizardAppWiz::Next(CAppWizStepDlg* pDlg)
{
	// Delegate to the dialog chooser
	return m_pChooser->Next(pDlg);
}

// This is called when the user clicks "Back" on one of the custom
//  AppWizard's steps.
CAppWizStepDlg* CAsmWizardAppWiz::Back(CAppWizStepDlg* pDlg)
{
	// Delegate to the dialog chooser
	return m_pChooser->Back(pDlg);
}

void CAsmWizardAppWiz::CustomizeProject(IBuildProject* pProject)
{
    CComPtr<IConfigurations> pConfigs;
    HRESULT hr=pProject->get_Configurations(&pConfigs);
    if(FAILED(hr))
    {
	    AfxMessageBox("An error occurred while obtaining the IConfigurations interface pointer");
	    return;
    }
    CComPtr<IConfiguration> pConfig;
    CComVariant index;
    VARIANT m_var = {0};
    CComBSTR Name;
    CComBSTR FileName;
    CString text;
    CString output;

    long Count=0;
    pConfigs->get_Count(&Count);   

    // Iterate through all the configurations of the project.
    for(int i=1; i <= Count; i++)
    {
	    index=i;
	    hr=pConfigs->Item(index, &pConfig);
	    if(FAILED(hr))
	    {
		    AfxMessageBox("An error occurred while obtaining the IConfiguration pointer");
		    return;
	    }
	    pConfig->get_Name(&Name);
	    text = Name;

        // �������ļ���
        FileName = m_Dictionary["Root"] + ".asm";
	    
	    if (text.Find("Debug") == -1)
		    output = "Release";
	    else
		    output = "Debug";

	    text.Format("/out:\"%s/%s.exe\"",output,m_Dictionary["Root"]);
        
        // ɾ��Ĭ�ϱ���ѡ��
        pConfig->RemoveToolSettings(L"CL.EXE", L"/D \"WIN32\"", m_var);
        pConfig->RemoveToolSettings(L"CL.EXE", L"/D \"_DEBUG\"", m_var);
        pConfig->RemoveToolSettings(L"CL.EXE", L"/D \"_WINDOWS\"", m_var);
        pConfig->RemoveToolSettings(L"CL.EXE", L"/D \"_AFXDLL\"", m_var);
        pConfig->RemoveToolSettings(L"CL.EXE", L"/D \"_MBCS\"", m_var);
        pConfig->RemoveToolSettings(L"CL.EXE", L"/D \"_AFXDLL\"", m_var);
        pConfig->RemoveToolSettings(L"RC.EXE", L"/d \"_AFXDLL\"", m_var);
        pConfig->RemoveToolSettings(L"LINK.EXE", L"/subsystem:windows", m_var);

        // �����Զ���ѡ��
        pConfig->AddToolSettings(L"mfc", L"0", m_var);

        // �жϵ�ǰ������������
        switch(m_ProjectType)
        {
            case 0:
                pConfig->AddToolSettings(L"CL.EXE", L"/nologo /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\"", m_var);
                // ����Ĭ��
                pConfig->MakeCurrentSettingsDefault(m_var);
                pConfig->AddToolSettings(L"LINK.EXE", L"/subsystem:windows kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib", m_var);  

                break;
            case 1:
                pConfig->AddToolSettings(L"CL.EXE", L"/nologo /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_CONSOLE\" /D \"_MBCS\"", m_var);
                // ����Ĭ��
                pConfig->MakeCurrentSettingsDefault(m_var);
                pConfig->AddToolSettings(L"LINK.EXE", L"/subsystem:console kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib", m_var);  

                break;
            case 2:
                pConfig->AddToolSettings(L"CL.EXE", L"/nologo /MTd /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"D_EXPORTS\"", m_var);
                pConfig->AddToolSettings(L"LINK.EXE", L"/subsystem:windows /DLL", m_var);
                break;
            case 3:
                pConfig->AddToolSettings(L"CL.EXE", L"/nologo /MLd /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_MBCS\" /D \"_LIB\"", m_var);
                pConfig->AddToolSettings(L"LIB.EXE", L"-lib", m_var);
                break;
            default:
                break;
        }
        
        // ����ָ���ļ��Ķ��ƹ���ѡ��
        pConfig->AddCustomBuildStepToFile(FileName, L"ml /c /coff /Zi /Fo $(TargetDir)\\$(InputName).obj $(InputPath)", L"$(TargetDir)\\$(InputName).obj", L"Performing Custom Build Step on $(InputPath)", m_var);
  
	    pConfig = NULL;
    }
    pConfigs = NULL;
}

// Here we define one instance of the CAsmWizardAppWiz class.  You can access
//  m_Dictionary and any other public members of this class through the
//  global AsmWizardaw.
CAsmWizardAppWiz AsmWizardaw;

