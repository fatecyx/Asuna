#include <iostream.h>
#include <string.h>
#include <stdlib.h>
#include "..\hde28c\hde32.h"
using namespace std;
#ifndef __DISASSEMBLER__


#define __DISASSEMBLER__ 1

/* Disassembler Flags:
-----------------------
*/

//the register flags
#define OP_REG_EAX 0x00000001
#define OP_REG_ECX 0x00000002
#define OP_REG_EDX 0x00000004
#define OP_REG_EBX 0x00000008
#define OP_REG_ESP 0x00000010
#define OP_REG_EBP 0x00000020
#define OP_REG_ESI 0x00000040
#define OP_REG_EDI 0x00000080
//for all registers
#define OP_REG_ALL 0x000000FF
#define OP_REG_ALL_EXP_EAX 0x000000FE

//Opcode States
#define OP_IMM8    0x00000100
#define OP_IMM32   0x00000200
#define OP_IMM     0x00000300        //IMM8 or IMM32 
#define OP_BITS8   0x00000400 
#define OP_BITS32  0x00000800
#define OP_RM_R    0x00001000        //Eb,Gb or Ev,Gv
#define OP_R_RM    0x00002000        //Gb,Eb or Gv,Ev
#define OP_RM_IMM  0x00004000        //Eb,Ib
#define OP_R_IMM   0x00008000        //Gb,Ib
#define OP_REG_EXT 0x00010000        //reg used as an opcode extention
#define OP_REG_ONLY 0x00020000       // like inc or dec
#define OP_RM_ONLY 0x00040000
#define OP_IMM_ONLY 0x00080000       // for push & pop
#define OP_RM_DISP 0x00100000        //disp only
#define OP_GROUP   0x00200000
#define OP_LOCK    0x00400000
/*
 *
 *  Copyright (C) 2010-2011 Amr Thabet <amr.thabet@student.alx.edu.eg>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to Amr Thabet 
 *  amr.thabet@student.alx.edu.eg
 *
 */


int imm_to_dec(string); 
extern string reg32[8];
#ifdef __DISASM__
//int dis_entries;
//FLAGTABLE*  FlagTable;
//extern int dis_entries;
//extern FLAGTABLE FlagTable[512*7];

extern string reg16[8];
extern string  reg8[8];
extern string   seg[6];
extern string rm_sizes[3];
extern string numbers[10];
extern string prefixes[3];
#endif
#endif       
