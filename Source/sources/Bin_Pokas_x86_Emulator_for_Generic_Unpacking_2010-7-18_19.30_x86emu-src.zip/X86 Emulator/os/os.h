#define __WIN32__  1    // we use windows
struct FileMapping{
            unsigned long hFile;
            unsigned long hMapping;
            unsigned long BaseAddress;
            unsigned long FileLength;
};
//unsigned long LoadProcess(string);
unsigned long GetTime();
FileMapping* OpenFile(const char*);
FileMapping* CreateNewFile(const char* Filename,unsigned long size);
unsigned long CloseFile(FileMapping*);
