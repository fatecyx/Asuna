//#include <cstdlib>
#include <string.h>
#include <windows.h>
#include "../../x86emu.h"


using namespace std;

 
unsigned long GetTime(){
    return GetTickCount();     
};
int main(int argc, char *argv[])
{  
     EnviromentVariables* vars= (EnviromentVariables*)malloc(sizeof(EnviromentVariables)); 
     memset( vars,0,sizeof(EnviromentVariables));
     vars->dllspath="C:\\Windows\\System32\\";
     vars->kernel32=(dword)GetModuleHandleA("kernel32.dll");
     vars->user32=(dword)LoadLibraryA("user32.dll");
     Process* c;
     System* sys=new System(vars);
     try{ 
         c=new Process(sys,"aspack.exe");
         
     }catch(int x){
            cout << "error == "<<x << "\n";
            system("PAUSE");
            return EXIT_SUCCESS;
     };
      
     try{
         c->debugger->AddBp("__isdirty(eip)");
      }catch(...){
                 cout << "error = " <<c->debugger->GetLastError() <<"\n";
     };
     cout<< "begin emulating...\n";
     int n=GetTime();
     string str;
     int layer=0;
Continue_th:      
     int x=c->emulate();//*/ 
     if (x!=EXP_BREAKPOINT){
        cout << "Error = " << x << "\n";
        system("PAUSE");
        return EXIT_SUCCESS;
     };                                                    
     if (layer<1){
        c->GetThread(0)->mem->cmem_length=0;
        layer++;
        goto Continue_th;
     };//*/
     c->emulatecommand();
     n=GetTime()-n;
     cout <<"Time (sec) = " << n <<" msecs\nDisassembled Code :\n";
           //this->threads[0]->Eip=0x00401000;                   //*************************
            dword eip=c->GetThread(0)->Eip;
     for (int i=0;i<56;i++){
         ins_disasm* ins=sys->disasm((ins_disasm*)malloc(sizeof(ins_disasm)),(char*)c->SharedMem->read_virtual_mem(eip),str);
         str.append("\n");
         char* s2=(char*)c->GetThread(0)->mem->read_virtual_mem(eip);
         cout <<(int*)eip << " : "<< str;
         eip+= ins->hde.len;
     };
     cout<< "end emulating...\n";
     ins_disasm* s;
     PEDump(c->GetThread(0)->Eip,c,"test.exe");
     system("PAUSE");
     return EXIT_SUCCESS;
} 
