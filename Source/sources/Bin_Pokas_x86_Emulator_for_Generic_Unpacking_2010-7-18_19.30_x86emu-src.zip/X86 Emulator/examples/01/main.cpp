#include <cstdlib>
#include <iostream>
#include "x86emu.h"
using namespace std;

int main(int argc, char *argv[])
{
    //First we will create the Environment Variables 
    //th Environment Variables is just some parameters or setting will be passed to the System 
    EnviromentVariables* vars=(EnviromentVariables*)malloc(sizeof(EnviromentVariables));
    //this variable should be adjusted to make the system perform well. this path is the path to the folder that contain 
    //the important dlls which are ("kernel32.dll","ntdll.dll","user32.dll")
    vars->dllspath="C:\\Windows\\system32\\";
    //there's other variables but we can ignore the right now 
    
    //now we will create the new system
    System* sys=new System(vars);
    
    //now We Will create a new Process (process here named cpu sorry for this mistake)
    Process* c=new Process(sys,"01.exe");      //cpu take two parameters system & the program filename
     
    //there's two commands to emulate c->emulate() & c->emulatecommand() but emulatecommand(int) still not used and 
    //it will be used when I support multithreading
    c->emulatecommand(); 
    //I make the structure support multithreading so when you get a thread you should use function GetThread(int index) to 
    //get the thread you need (until now you should set the index=0)
    cout << (int*)c->GetThread(0)->Eip << "\n";
    //ins_disasm is a stucture that contain all the needed information about any instruction (will also the emualtion function)
    //you should create a buffer for it to pass it to the disassembler to fill it
    ins_disasm* ins=(ins_disasm*)malloc(sizeof(ins_disasm));
    string s;
    //there's two functions for disassembling 
    //1.disasm(buffer,Pointer) -->fill only the buffer with the needed information about the instruction
    //2.disasm(buffer,Pointer.string&) -->it calls no.1 and add to it the disassembled instruction in mnemonic string
    sys->disasm(ins,(char*)c->GetThread(0)->Eip,s);     //this call to no.2 and pass the buffer,Eip and the string to fill
    
    //let's see
    cout << s << "\n";
    //let's see what's the changes in Esp register
    cout << (int*)c->GetThread(0)->Exx[4] << "\n";      //(int*) make it written at the console in hexdecimal shape
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
