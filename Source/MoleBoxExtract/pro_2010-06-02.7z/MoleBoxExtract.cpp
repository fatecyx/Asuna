#pragma comment(lib, "shlwapi.lib")
#pragma comment(linker,"/ENTRY:DllMain")
#pragma comment(linker,"/MERGE:.text=.Kaede /SECTION:.Kaede,ERW")
#pragma comment(linker,"/MERGE:.data=.Kaede")
#pragma comment(linker,"/MERGE:.rdata=.Kaede")

#include "MoleBoxExtract.h"
#include <Shlwapi.h>
#include <stdio.h>
#include "nt_api.h"
#include "my_mem.h"
#include "my_common.h"

BOOL  bGetFileTime = FALSE;
DWORD dwSection = 0, dwPackageCount = 0, dwMaxPackage = 10;
TMoleBoxFile  **pMoleBoxFile     = NULL;
PIMAGE_SECTION_HEADER gpSectionHeader;

CREATEFILEA    *F_CreateFileA    = NULL;
GETFILESIZE    *F_GetFileSize    = NULL;
READFILE       *F_ReadFile       = NULL;
CLOSEHANDLE    *F_CloseHandle    = NULL;
FINDCLOSE      *F_FindClose      = NULL;
FINDFIRSTFILEA *F_FindFirstFileA = NULL;
FINDNEXTFILEA  *F_FindNextFileA  = NULL;

BOOL APIENTRY DllMain(HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
    static BOOL bInit = FALSE;

    if (ul_reason_for_call != DLL_PROCESS_ATTACH || bInit == TRUE)
        return TRUE;

    INT32                    EP;
    PIMAGE_DOS_HEADER        pDosHeader;
    PIMAGE_OPTIONAL_HEADER32 pOptionalHeader;
    PIMAGE_IMPORT_DESCRIPTOR pImportDescriptor;

    bInit = TRUE;
    pDosHeader = (PIMAGE_DOS_HEADER)GetModuleHandleA(0);
    pOptionalHeader = (PIMAGE_OPTIONAL_HEADER32)((PBYTE)pDosHeader + pDosHeader->e_lfanew + 4 + sizeof(IMAGE_FILE_HEADER));
    pImportDescriptor = (PIMAGE_IMPORT_DESCRIPTOR)(pOptionalHeader->DataDirectory[1].VirtualAddress + (DWORD)pDosHeader);

    MessageBoxA(NULL, "û���ļ������", 0, 64);
    do
    {
        if (lstrcmpiA((LPCSTR)pImportDescriptor->Name + (DWORD)pDosHeader, "KERNEL32.dll") == 0)
        {
            DWORD   dwFuncAddr;
            LPDWORD lpFuncAddr = (LPDWORD)pImportDescriptor->FirstThunk + (DWORD)pDosHeader / 4;

            while (dwFuncAddr = *lpFuncAddr)
            {
                if (dwFuncAddr == (DWORD)GetProcAddress) *lpFuncAddr = (DWORD)MyGetProcAddress;
                else if (dwFuncAddr == (DWORD)VirtualProtect) *lpFuncAddr = (DWORD)MyVirtualProtect;
                else if (dwFuncAddr == (DWORD)GetFileTime) *lpFuncAddr = (DWORD)MyGetFileTime;
                else if (dwFuncAddr == (DWORD)CharUpperBuffA) *lpFuncAddr = (DWORD)MyCharUpperBuffA;
                else if (dwFuncAddr == (DWORD)GetModuleHandleA) *lpFuncAddr = (DWORD)MyGetModuleHandleA;
                else if (dwFuncAddr == (DWORD)LoadLibraryExA) *lpFuncAddr = (DWORD)MyLoadLibraryExA;
                ++lpFuncAddr;
            }
        }

        ++pImportDescriptor;
    } while (pImportDescriptor->FirstThunk);

    EP = (INT32)pDosHeader + pOptionalHeader->AddressOfEntryPoint;
    if (*(PBYTE)EP == 0xE8)
    {
        EP += *(PINT32)((PBYTE)(EP + 1)) + 5;
        if (*(PBYTE)EP++ == 0x60)     // pushad
        {
            gpSectionHeader = (PIMAGE_SECTION_HEADER)(EP + 6 - 0x3FA - 1);
            EP += *(PINT32)((PBYTE)(EP + 1)) + 5;
            EP += *(PINT32)((PBYTE)(EP + 1)) + 5;
            while (*(PINT32)EP != 0xE8D0FF58)
            {
                ++EP;
            }
            ++EP;
            *(PBYTE)EP = JUMP;
            *(PINT32)(EP + 1) = (DWORD)MyEntryPoint - (EP + 5);
        }
    }

    pMoleBoxFile = (TMoleBoxFile **)HeapAlloc(Nt_GetProcessHeap(),
                        HEAP_ZERO_MEMORY, dwMaxPackage * sizeof(*pMoleBoxFile));

    return TRUE;
}

HMODULE WINAPI MyLoadLibraryExA(LPCSTR lpLibFileName, HANDLE hFile, DWORD dwFlags)
{
    HMODULE hModule = LoadLibraryExA(lpLibFileName, hFile, dwFlags);
    return hModule ? hModule : GetModuleHandleA(0);
}

HRESULT WINAPI MyGetFileTime(HANDLE hFile, LPFILETIME lpCreationTime, LPFILETIME lpLastAccessTime, LPFILETIME lpLastWriteTime)
{
    if (bGetFileTime == FALSE)
    {
        bGetFileTime = TRUE;
    }

    return GetFileTime(hFile, lpCreationTime, lpLastAccessTime, lpLastWriteTime);
}

DWORD WINAPI MyCharUpperBuffA(LPSTR lpsz, DWORD cchLength)
{
    if (bGetFileTime == TRUE)
    {
        LPSTR lpFileName;
        DWORD dwCount = dwPackageCount++;

        bGetFileTime = FALSE;
        lpFileName = lpsz;
        while ((LPSTR)*(LPDWORD)lpFileName != lpsz)
        {
            lpFileName += lstrlenA(lpFileName) + 1;
        }
        if (dwCount >= dwMaxPackage)
        {
            dwMaxPackage += dwMaxPackage >> 1;
            pMoleBoxFile = (TMoleBoxFile **)HeapReAlloc(Nt_GetProcessHeap(),
                HEAP_ZERO_MEMORY, pMoleBoxFile, dwMaxPackage * sizeof(*pMoleBoxFile));
        }
        pMoleBoxFile[dwCount] = (TMoleBoxFile *)(lpFileName);
    }

    return CharUpperBuffA(lpsz, cchLength);
}

int WINAPI MyEntryPoint()
{
    if (pMoleBoxFile == NULL)
    {
        CHAR szModule[MAX_PATH];
        GetModuleFileNameA(NULL, szModule, sizeof(szModule));
        MessageBoxA(NULL, "û���ļ������", szModule, 64);
    }
    else
    {
        for (DWORD i = 0; i != dwPackageCount; ++i)
            Extract2(*F_ReadFile, *F_GetFileSize, *F_CreateFileA, *F_CloseHandle, *F_FindFirstFileA, *F_FindNextFileA, *F_FindClose, pMoleBoxFile[i]);
    }
    ExitProcess(0);
}

BOOL WINAPI MyVirtualProtect(LPVOID lpAddress, SIZE_T dwSize, DWORD flNewProtect, PDWORD lpflOldProtect)
{
    PBYTE pReturn;
    DWORD dwAddress = *(LPDWORD)lpAddress;

    __asm
    {
        lea eax, lpAddress - 4;
        mov eax, dword ptr [eax];
        mov pReturn, eax;
    }

    if (*(LPWORD)pReturn == 0xC085 && *(pReturn + 2) == 0x75)
    {
        if (F_CreateFileA == NULL && dwAddress == (DWORD)CreateFileA)
        {
            F_CreateFileA = (CREATEFILEA *)lpAddress;
        }
        else if (F_ReadFile == NULL && dwAddress == (DWORD)ReadFile)
        {
            F_ReadFile = (READFILE *)lpAddress;
        }
        else if (F_GetFileSize == NULL && dwAddress == (DWORD)GetFileSize)
        {
            F_GetFileSize = (GETFILESIZE *)lpAddress;
        }
        else if (F_FindFirstFileA == NULL && dwAddress == (DWORD)FindFirstFileA)
        {
            F_FindFirstFileA = (FINDFIRSTFILEA *)lpAddress;
        }
        else if (F_FindNextFileA == NULL && dwAddress == (DWORD)FindNextFileA)
        {
            F_FindNextFileA = (FINDNEXTFILEA *)lpAddress;
        }
        else if (F_CloseHandle == NULL && dwAddress == (DWORD)CloseHandle)
        {
            F_CloseHandle = (CLOSEHANDLE *)lpAddress;
        }
        else if (F_FindClose == NULL && dwAddress == (DWORD)FindClose)
        {
            F_FindClose = (FINDCLOSE *)lpAddress;
        }
    }

    return VirtualProtect(lpAddress, dwSize, flNewProtect, lpflOldProtect);
}

HMODULE WINAPI MyGetModuleHandleA(LPCSTR lpModuleName)
{
    if (lpModuleName)
    {
        if (lstrcmpiA(lpModuleName, "oleoaut32.dll") == 0)
        {
            MyEntryPoint();
        }
    }

    return GetModuleHandleA(lpModuleName);
}

FARPROC WINAPI MyGetProcAddress(HMODULE hModule, LPCSTR lpProcName)
{
    if ((int)lpProcName > 0xFFFF)
    {
        DWORD dwHash = HashAPI(lpProcName);
        switch (dwHash)
        {
        case 0x9EE7BFA2: return (FARPROC)MyGetFileTime;
        case 0x6C719644: return (FARPROC)MyVirtualProtect;
        case 0x96A5CDE9: return (FARPROC)MyCharUpperBuffA;
        case 0x5929952D: return (FARPROC)MyGetModuleHandleA;
        case 0xFA83CC97: return (FARPROC)MyLoadLibraryExA;
        }
    }

    return GetProcAddress(hModule, lpProcName);
}

DWORD WINAPI uncompress(BYTE *dest, ULONG *destLen, const BYTE *source, ULONG sourceLen, LONG)
{
    DWORD status, NumberOfSections;

    __asm mov status, eax;

    NumberOfSections = *(int *)((PBYTE)gpSectionHeader - 4) - 3;
    if (dwSection < NumberOfSections)
    {
        gpSectionHeader[dwSection++].SizeOfRawData = *destLen;
        while (dwSection < NumberOfSections && gpSectionHeader[dwSection].VirtualAddress == 0)
        {
            ++dwSection;
        }
    }

    return status != 0;
}

NoInline void UnpackExe(LPSTR lpOutPath)
{
    DWORD   dwLength, dwHeaderSize, dwCurPos;
    HANDLE  hFile;
    CHAR   szModuleName[0x1000];
    PIMAGE_DOS_HEADER        pDosHeader;
    PIMAGE_FILE_HEADER       pFileHeader;
    PIMAGE_OPTIONAL_HEADER32 pOptionalHeader;
    PIMAGE_SECTION_HEADER    pSectionHeader;
    static Bool bUnpacked = False;

    if (bUnpacked == True || dwSection == 0)
        return;

    bUnpacked = True;
    pDosHeader = (PIMAGE_DOS_HEADER)GetModuleHandle(0);
    if (VirtualProtectEx((HANDLE)-1, pDosHeader, 0x1000, PAGE_READWRITE, &dwLength) == False)
        return;

    pFileHeader     = (PIMAGE_FILE_HEADER)((PBYTE)pDosHeader + pDosHeader->e_lfanew + 4);
    pOptionalHeader = (PIMAGE_OPTIONAL_HEADER32)((PBYTE)pFileHeader + sizeof(*pFileHeader));
//    pSectionHeader  = (PIMAGE_SECTION_HEADER)((PBYTE)pOptionalHeader + sizeof(*pOptionalHeader));
    pSectionHeader  = (PIMAGE_SECTION_HEADER)((PBYTE)pOptionalHeader + pFileHeader->SizeOfOptionalHeader);

    pFileHeader->NumberOfSections = *(LPWORD)((PBYTE)gpSectionHeader - 4) - 3;
    memcpy(pSectionHeader, gpSectionHeader, pFileHeader->NumberOfSections * sizeof(*pSectionHeader));

    for (int i = pFileHeader->NumberOfSections; i--; )
    {
        if (pSectionHeader[i].SizeOfRawData == 0 || pSectionHeader[i].VirtualAddress == 0)
            continue;

        DWORD dwSize;

        dwSize = pSectionHeader[i].SizeOfRawData;
        dwSize += pOptionalHeader->SectionAlignment - dwSize % pOptionalHeader->SectionAlignment;
        if (VirtualProtectEx((HANDLE)-1,
            pSectionHeader[i].VirtualAddress + (PBYTE)pDosHeader,
            dwSize, PAGE_READWRITE, &dwLength) == False)
        {
            return;
        }
    }

    GetModuleFileNameA(0, szModuleName, countof(szModuleName));
    dwLength = lstrlenA(lpOutPath);
    *(LPDWORD)&lpOutPath[dwLength] = '\\';
    lstrcpyA(&lpOutPath[dwLength + 1], PathFindFileNameA(szModuleName));

    hFile = CreateFileA(lpOutPath,
                GENERIC_READ|GENERIC_WRITE,
                FILE_SHARE_READ|FILE_SHARE_WRITE,
                NULL,
                CREATE_ALWAYS,
                FILE_ATTRIBUTE_NORMAL,
                NULL);
    *(LPDWORD)&lpOutPath[dwLength] = 0;
    if (hFile == INVALID_HANDLE_VALUE)
        return;

    dwLength = (PBYTE)&pSectionHeader[pFileHeader->NumberOfSections] - (PBYTE)pDosHeader;

    memset(szModuleName, 0, sizeof(szModuleName));
    WriteFile(hFile, pDosHeader, dwLength, &dwHeaderSize, NULL);
    if (dwLength = dwHeaderSize % pOptionalHeader->FileAlignment)
    {
        dwLength = pOptionalHeader->FileAlignment - dwLength;
        WriteFile(hFile, szModuleName, dwLength, &dwLength, NULL);
    }

    pFileHeader->Characteristics = IMAGE_FILE_32BIT_MACHINE|IMAGE_FILE_EXECUTABLE_IMAGE|IMAGE_FILE_RELOCS_STRIPPED;
    pOptionalHeader->MajorLinkerVersion = _MSC_VER / 100 - 6;
    pOptionalHeader->MinorLinkerVersion = 0;
    pOptionalHeader->SizeOfCode = 0;
    pOptionalHeader->AddressOfEntryPoint = 0;
    pOptionalHeader->CheckSum = 0;
    pOptionalHeader->SizeOfImage = pOptionalHeader->SizeOfHeaders;
    pOptionalHeader->DataDirectory[12].VirtualAddress = 0;
    pOptionalHeader->DataDirectory[12].Size = 0;

    dwCurPos = dwHeaderSize + dwLength;
    for (int i = 0; i != pFileHeader->NumberOfSections; ++i)
    {
        DWORD dwSize;

        if (pSectionHeader[i].VirtualAddress == 0)
        {
            pSectionHeader[i].VirtualAddress = pOptionalHeader->DataDirectory[2].VirtualAddress;
        }

        if (pSectionHeader[i].VirtualAddress == 0)
            continue;

        dwSize = pSectionHeader[i].Misc.VirtualSize;
        dwSize += pOptionalHeader->SectionAlignment - dwSize % pOptionalHeader->SectionAlignment;
        pOptionalHeader->SizeOfImage += dwSize;
        pSectionHeader[i].PointerToRawData = dwCurPos;
        if (pSectionHeader[i].SizeOfRawData == 0)
            continue;

        dwSize = pSectionHeader[i].SizeOfRawData;
        if (dwSize % pOptionalHeader->FileAlignment)
            dwSize += pOptionalHeader->FileAlignment - dwSize % pOptionalHeader->FileAlignment;
        WriteFile(hFile,
            pSectionHeader[i].VirtualAddress + (PBYTE)pDosHeader,
            dwSize,
            &dwLength,
            NULL);

        dwCurPos += dwLength;
    }

    SetFilePointer(hFile, 0, 0, FILE_BEGIN);
    WriteFile(hFile, pDosHeader, dwHeaderSize, &dwLength, NULL);
    CloseHandle(hFile);
}

Void WINAPI Extract2(READFILE       lpfnReadFile,
                     GETFILESIZE    lpfnGetFileSize,
                     CREATEFILEA    lpfnCreateFileA,
                     CLOSEHANDLE    lpfnCloseHandle,
                     FINDFIRSTFILEA lpfnFindFirstFileA,
                     FINDNEXTFILEA  lpfnFindNextFileA,
                     FINDCLOSE      lpfnFindClose,
                     TMoleBoxFile  *pMoleBoxFile)
{
    HANDLE hFile, hFind, hHeap;
    WIN32_FIND_DATAA wfd;
    CHAR  c, c1, szFileName[_MAX_FNAME], szPath[_MAX_FNAME];
    LPSTR lpName, lpFileName, lpExtension;
    PBYTE pbFile;
	DWORD dwRead, dwLength, dwSize, dwMaxSize = 0;

    GetModuleFileNameA(NULL, szFileName, sizeof(szFileName));
    lpFileName = PathFindFileNameA(szFileName);
    *(lpFileName - 1) = 0;
    SetCurrentDirectoryA(szFileName);
    lpExtension = PathFindExtensionA(lpFileName);
    if (lpExtension)
    {
        *lpExtension = 0;
    }
    wsprintf(szPath, "%s_Files\\", lpFileName);
	if (CreateDirectory(szPath, NULL) == FALSE && GetFileAttributesA(szPath) == -1)
    {
        MessageBoxA(NULL, "CreateDirectoryA() failed", NULL, 64);
        return;
    }

    MessageBoxA(NULL, "CreateDirectoryA() failed", NULL, 64);
    UnpackExe(szPath);

    hHeap  = GetProcessHeap();
	pbFile = (PBYTE)HeapAlloc(hHeap, 0, 0);

    dwLength = lstrlenA(szPath);
    while (lpFileName = pMoleBoxFile->lpFileName)
    {
        lpName = PathFindFileNameA(lpFileName);
        if (lpName != lpFileName)
        {
            DWORD dwAttributes;

            lstrcpyA(szFileName, szPath);
            c1 = *lpName;
            *lpName = 0;

            lstrcpyA(&szFileName[dwLength], lpFileName);
            dwAttributes = GetFileAttributesA(szFileName);
            szFileName[dwLength] = 0;

            if (dwAttributes == -1) do
            {
                if (*lpFileName == '\\' || *lpFileName == '/')
                {
                    c = *lpFileName;
                    *lpFileName = 0;
                    hFind = lpfnFindFirstFileA(pMoleBoxFile->lpFileName, &wfd);
                    if (hFind != INVALID_HANDLE_VALUE)
                    {
                        lstrcatA(szFileName, wfd.cFileName);
                        lstrcatA(szFileName, "\\");
                        CreateDirectoryA(szFileName, NULL);
                        lpfnFindClose(hFind);
                    }
                    *lpFileName = c;
                }
                ++lpFileName;
            } while (*lpFileName);
            else
            {
                lstrcatA(szFileName, lpFileName);
            }

            *lpName = c1;
        }
        else
        {
            szFileName[0] = 0;
        }

        hFind = lpfnFindFirstFileA(pMoleBoxFile->lpFileName, &wfd);
        if (hFind != INVALID_HANDLE_VALUE)
        {
            lpfnFindClose(hFind);
            hFile = lpfnCreateFileA(pMoleBoxFile->lpFileName,
                            GENERIC_READ,
                            FILE_SHARE_READ,
                            NULL,
                            OPEN_EXISTING,
                            FILE_ATTRIBUTE_NORMAL,
							NULL);
            if (hFile != INVALID_HANDLE_VALUE)
            {
                dwSize = lpfnGetFileSize(hFile, NULL);
                if (dwSize > dwMaxSize)
                {
                    pbFile = (PBYTE)HeapReAlloc(hHeap, 0, pbFile, dwSize);
                    dwMaxSize = dwSize;
                }
                if (lpfnReadFile(hFile, pbFile, dwSize, &dwRead, NULL) == TRUE)
                {
                    if (szFileName[0])
                    {
                        lstrcatA(szFileName, wfd.cFileName);
                    }
                    else
                    {
                        wsprintfA(szFileName, "%s%s", szPath, wfd.cFileName);
                    }

                    hFile = CreateFileA(szFileName,
                                GENERIC_WRITE,
                                FILE_SHARE_WRITE,
                                NULL,
                                CREATE_ALWAYS,
                                FILE_ATTRIBUTE_NORMAL,
                                NULL);
                    if (hFile != INVALID_HANDLE_VALUE)
                    {
                        WriteFile(hFile, pbFile, dwSize, &dwRead, NULL);
                        CloseHandle(hFile);
                    }
                }
                else
                {
                    wsprintfA(szFileName, "��ȡ\"%s\"ʧ��.", lpFileName);
                    MessageBoxA(NULL, szFileName, NULL, 64);
                }
                lpfnCloseHandle(hFile);
            }
        }

        ++pMoleBoxFile;
    }

    HeapFree(hHeap, 0, pbFile);
}

BOOL WINAPI MyCreateDirectory(LPCTSTR lpPathName)
{
    LPTSTR lpPath = (LPTSTR)lpPathName;

    if (*lpPath == 0)
    {
        return FALSE;
    }

    do
    {
        if (*lpPath == '\\')
        {
            if (*(lpPath + 1) == 0)
            {
                break;
            }
            *lpPath = 0;
            CreateDirectory(lpPathName, NULL);
            *lpPath = '\\';
        }
        ++lpPath;
    } while (*lpPath);

    return CreateDirectory(lpPathName, NULL);
}

Void WINAPI Extract(READFILE      lpfnReadFile,
                    GETFILESIZE   lpfnGetFileSize,
                    CREATEFILEA   lpfnCreateFileA,
                    TMoleBoxFile *lpNames,
                    DWORD         dwFileNum)
{
	CHAR	szFileName[_MAX_FNAME], szPath[_MAX_FNAME];
	PBYTE	pbFile;
	DWORD	dwRead, dwSize, dwMaxSize = 0;
	HANDLE	hFile, hHeap;
	LPSTR	lpTemp, lpExtension, lpFileName;

    GetModuleFileNameA(NULL, szFileName, sizeof(szFileName));
    lpFileName = PathFindFileNameA(szFileName);
    *(lpFileName - 1) = 0;
    SetCurrentDirectoryA(szFileName);
    lpExtension = PathFindExtensionA(lpFileName);
    if (lpExtension)
    {
        *lpExtension = 0;
    }
    wsprintf(szPath, "%s_Files", lpFileName);

	hHeap = GetProcessHeap();
	pbFile = (PBYTE)HeapAlloc(hHeap, 0, 0);
	CreateDirectory(szPath, NULL);

	while (dwFileNum--)
    {
        lpFileName = lpNames[dwFileNum].lpFileName;
		hFile = lpfnCreateFileA(lpFileName,
							GENERIC_READ,
							FILE_SHARE_READ,
							NULL,
							OPEN_EXISTING,
							FILE_ATTRIBUTE_NORMAL,
							NULL);

		if (hFile != INVALID_HANDLE_VALUE)
		{
			dwSize = lpfnGetFileSize(hFile, NULL);
			if (dwSize > dwMaxSize)
			{
				pbFile = (PBYTE)HeapReAlloc(hHeap, 0, pbFile, dwSize);
				dwMaxSize = dwSize;
			}

			lpfnReadFile(hFile, pbFile, dwSize, &dwRead, NULL);
			CloseHandle(hFile);

			lpTemp = PathFindFileNameA(lpFileName);
			if (lpTemp != lpFileName)
			{
				BYTE byTemp = *lpTemp;
				*lpTemp = 0;
				wsprintf(szFileName, "%s\\%s", szPath, lpFileName);
				MyCreateDirectory(szFileName);
				*lpTemp = byTemp;
			}
			wsprintf(szFileName, "%s\\%s", szPath, lpFileName);

			hFile = CreateFileA(szFileName,
				GENERIC_WRITE,
				FILE_SHARE_WRITE,
				NULL,
                CREATE_ALWAYS,
				FILE_ATTRIBUTE_NORMAL,
				NULL);
			if (hFile != INVALID_HANDLE_VALUE)
			{
				WriteFile(hFile, pbFile, dwSize, &dwRead, NULL);
				CloseHandle(hFile);
			}
		}
	}

	HeapFree(hHeap, 0, pbFile);
}
