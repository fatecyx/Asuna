//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BinarySplitter.rc
//
#define IDD_SPLIT                       107
#define IDD_MERGE                       108
#define IDD_ABOUT                       109
#define IDB_SPLIT                       111
#define IDB_MERGE                       112
#define IDB_OPTION                      113
#define IDC_SPLIT_EDIT_INPUT            1000
#define IDC_SPLIT_BUTTON_INPUT_BROWSE   1001
#define IDC_SPLIT_EDIT_OUTPUT           1002
#define IDC_SPLIT_BUTTON_OUTPUT_BROWSE  1003
#define IDC_SPLIT_COMBO_SLICE_SIZE      1004
#define IDC_SPLIT_CHECK_COMPRESS        1005
#define IDC_SPLIT_CHECK_ENCRYPT         1006
#define IDC_SPLIT_BUTTON_SPLIT          1007
#define IDC_SPLIT_EDIT_PASSWORD         1008
#define IDC_SPLIT_PROGRESS              1009
#define IDC_SPLIT_CHECK_ORIGNAME        1010
#define IDC_SPLIT_STATIC_INPUT          1016
#define IDC_SPLIT_STATIC_OUTPUT         1017
#define IDC_SPLIT_STATIC_VOLUME         1018
#define IDC_MERGE_CHECK_ORIGNAME        1019
#define IDC_MERGE_BUTTON_INPUT_BROWSE   1020
#define IDC_MERGE_BUTTON_OUTPUT_BROWSE  1021
#define IDC_MERGE_BUTTON_OPEN           1022
#define IDC_MERGE_BUTTON_MERGE          1023
#define IDC_MERGE_EDIT_PASSWORD         1024
#define IDC_MERGE_EDIT_INPUT            1025
#define IDC_MERGE_EDIT_OUTPUT           1026
#define IDC_MERGE_PROGRESS              1027
#define IDC_MERGE_PWDTIP                1028

#define IDC_BUTTON_FORCE_STOP           2012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        119
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
