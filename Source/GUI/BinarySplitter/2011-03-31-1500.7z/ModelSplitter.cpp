#include "ModelSplitter.h"
#include "sha256.h"
#include "LZMA/C/Lzma86.h"
#include "BinarySplitterMsg.h"

#define PART_FILE_SUFFIX _T("part")

#define LOOP_ALWAYS() for (Bool __condition_ = True; __condition_; )
#define LOOP_ONCE()   for (Bool __condition_ = True; __condition_; __condition_ = False)

Int CModelSplitter::GenerateOutputFileName(PCTChar pszOutFile, PTChar pszBuffer, Int64 Index)
{
    return FormatString(pszBuffer, _T("%s.%s%d"), pszOutFile, PART_FILE_SUFFIX, Index);
}

Long
CModelSplitter::
VerifyIsOutputFileExist(
    PCTChar pszInFile,
    PTChar  pszOutFile,
    SizeT   BufferCount,
    Int64   SliceSizeInByte
)
{
    Int64  Parts, Index;
    HANDLE hFile;
    TChar  szBuffer[MAX_PATH + 30];
    LARGE_INTEGER FileSize;

    UNUSED_VARIABLE(BufferCount);

    hFile = CreateFile(
                pszInFile,
                GENERIC_READ,
                0,
                NULL,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL,
                NULL);
    if (hFile == INVALID_HANDLE_VALUE)
        return BSERR_OPEN_FILE;

    GetFileSizeEx(hFile, &FileSize);
    CloseHandle(hFile);

    if ((UInt64)SliceSizeInByte > (UInt64)FileSize.QuadPart)
        return BSERR_INVALID_SLICE_SIZE;

    Parts = FileSize.QuadPart / SliceSizeInByte;
    if (pszOutFile[0] == 0)
    {
        lstrcpy(szBuffer, pszInFile);
        rmext(szBuffer);
    }
    else
    {
        lstrcpy(szBuffer, pszOutFile);
    }

    Index = 0;
    do
    {
        GenerateOutputFileName(szBuffer, pszOutFile, Index++);
        if (IsPathExists(pszOutFile))
            return BSERR_NORMAL;

    } while (--Parts);

    return BSERR_SUCCESS;
}

Long CModelSplitter::Split(SPLIT_OPTION *pSplitOption)
{
#if defined(UNICODE) || defined(_UNICODE)
    TChar           szBuffer[MAX_PATH + 30];
#else
    TChar           szBuffer[MAX_PASSWORD_LENGTH];
#endif

    Long            Status;
    ULong           ThreadPoosFlags;
    HANDLE          hEvent;
    CSafeHandleFile hFile;
    LARGE_INTEGER   FileSize;
    SYSTEM_INFO     SystemInfo;

    SPLIT_WORK_THREAD_INFO *pInfo;

    if (pSplitOption == NULL)
        return BSERR_INVALID_PARAM;

    hFile = CreateFile(
                pSplitOption->InputFile,
                GENERIC_READ,
                FILE_SHARE_READ,
                NULL,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OVERLAPPED,
                NULL);
    if (hFile == INVALID_HANDLE_VALUE)
        return BSERR_OPEN_FILE;

    if (!GetFileSizeEx(hFile, &FileSize))
        return BSERR_GET_FILE_SIZE;

    if (FileSize.QuadPart == 0)
        return BSERR_ZERO_FILE_SIZE;

    if (FileSize.QuadPart < pSplitOption->SpliceSizeInByte.QuadPart)
        return BSERR_INVALID_SLICE_SIZE;

    hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    if (hEvent == NULL)
        return BSERR_NORMAL;

    pInfo = new SPLIT_WORK_THREAD_INFO;
    if (pInfo == NULL)
    {
        CloseHandle(hEvent);
        return BSERR_OUT_OF_MEMORY;
    }

    if (pSplitOption->OutputFile.IsEmpty())
    {
        pSplitOption->InputFile.CopyTo(szBuffer, countof(szBuffer));
        rmext(szBuffer);
    }
    else
    {
        pSplitOption->OutputFile.CopyTo(szBuffer, countof(szBuffer));
    }

    pInfo->CurrentThreadIndex   = 0;
    pInfo->bForceStop           = False;
    pInfo->InputFile            = pSplitOption->InputFile;
    pInfo->OutputFile           = szBuffer;
    pInfo->This                 = this;
    pInfo->Flags = 0;

    if (pSplitOption->fCompress)     pInfo->Flags |= SPLIT_FLAG_COMPRESS;
    if (pSplitOption->fEncrypt)      pInfo->Flags |= SPLIT_FLAG_ENCRYPT;
    if (pSplitOption->fSaveFileName) pInfo->Flags |= SPLIT_FLAG_SAVE_ORIG_NAME;

    if (!pSplitOption->Password.IsEmpty())
    {
#if defined(UNICODE) || defined(_UNICODE)
        pInfo->Password = pSplitOption->Password;
#else
        MultiByteToWideChar(CP_ACP, 0, pSplitOption->Password, -1, (PWChar)szBuffer, sizeof(szBuffer) / sizeof(WChar));
        pInfo->Password = (PWChar)szBuffer;
#endif
    }
    else
    {
        pInfo->Flags &= ~SPLIT_FLAG_ENCRYPT;
    }

    pInfo->CallbackParam        = pSplitOption->CallbackParam;
    pInfo->pfShowStatus         = pSplitOption->pfShowStatus;
    pInfo->pfShowErrorMessage   = pSplitOption->pfShowErrorMessage;
    pInfo->pfShowAskMessage     = pSplitOption->pfShowAskMessage;
    pInfo->hEventFirstSignal    = hEvent;
    InitializeCriticalSectionAndSpinCount(&pInfo->cs, 4000);

    pInfo->BytesProcessed.QuadPart = 0;
    pInfo->FileSize.QuadPart       = FileSize.QuadPart;
    pInfo->SpliceSizeInByte        = pSplitOption->SpliceSizeInByte;

    if (!pSplitOption->fCompress)
        pInfo->SpliceSizeInByte.QuadPart -= sizeof(BS_PART_FILE_HEADER);

    {
        UInt32 FirstPartOverHead;
        union
        {
            BS_PART_FILE_HEADER       FileHeader;
            BS_PART_FILE_HEADER_FIRST FileHeaderFirst;
        };

        UNUSED_VARIABLE(FileHeader);

        FirstPartOverHead  = sizeof(FileHeaderFirst) - sizeof(FileHeader);
        FirstPartOverHead -= sizeof(FileHeaderFirst.FileNameLength);
        FirstPartOverHead -= sizeof(FileHeaderFirst.OriginalFileName);

        if (TEST_BITS(pInfo->Flags, SPLIT_FLAG_SAVE_ORIG_NAME))
        {
            FirstPartOverHead += sizeof(FileHeaderFirst.FileNameLength);

#if defined(UNICODE) || defined(_UNICODE)
            FirstPartOverHead += StrLengthW(findnamew(pInfo->InputFile)) * sizeof(WChar);
#else
            FirstPartOverHead += (MultiByteToWideChar(CP_ACP, 0, findnamea(pInfo->InputFile), -1, NULL, 0) - 1) * sizeof(WChar);
#endif
        }

        pInfo->FirstPartOverhead = FirstPartOverHead;
        pInfo->FirstPartSliceInByte.QuadPart = pInfo->SpliceSizeInByte.QuadPart - FirstPartOverHead;
    }

    pInfo->Parts = (FileSize.QuadPart - pInfo->FirstPartSliceInByte.QuadPart - 1) / pInfo->SpliceSizeInByte.QuadPart + 1 + 1;
    pInfo->RefCount = pInfo->Parts;

    Status = BSERR_SUCCESS;

    UNUSED_VARIABLE(SystemInfo);
//    GetSystemInfo(&SystemInfo);

    ThreadPoosFlags = WT_EXECUTEDEFAULT;
//    WT_SET_MAX_THREADPOOL_THREADS(ThreadPoosFlags, SystemInfo.dwNumberOfProcessors);

    for (UInt32 Index = pInfo->Parts; Index; --Index)
    {
        if (!QueueUserWorkItem(
                 (LPTHREAD_START_ROUTINE)SplitWorkCallback,
                 pInfo,
                 ThreadPoosFlags))
        {
            if (Index == pInfo->Parts)
            {
                SetEvent(hEvent);
                DeleteCriticalSection(&pInfo->cs);
                delete pInfo;
            }

            Status = BSERR_QUEUE_USER_WORD_ITEM;
            break;
        }

    }

    WaitForSingleObjectEx(hEvent, INFINITE, FALSE);
    CloseHandle(hEvent);

    return Status;
}

Long CModelSplitter::Merge(MERGE_OPTION *pMergeOption)
{
    MERGE_WORK_THREAD_INFO *pInfo;

    pInfo = new MERGE_WORK_THREAD_INFO;
    if (pInfo == NULL)
        return BSERR_OUT_OF_MEMORY;

    pInfo->InputFile            = pMergeOption->InputFile;
    pInfo->CallbackParam        = pMergeOption->CallbackParam;
    pInfo->pfShowErrorMessage   = pMergeOption->pfShowErrorMessage;
    pInfo->pfShowAskMessage     = pMergeOption->pfShowAskMessage;
    pInfo->pfShowStatusMessage  = pMergeOption->pfShowStatusMessage;
    pInfo->pfShowStatus         = pMergeOption->pfShowStatus;
    pInfo->Password             = pMergeOption->Password;
    pInfo->This                 = this;
    pInfo->Flags                = 0;

    if (pMergeOption->OutputFile.IsEmpty())
    {
        pInfo->OutputFile = pInfo->InputFile;
        pInfo->OutputFile.ReplaceExtension(_T(".bin"));
    }
    else
    {
        pInfo->OutputFile = pMergeOption->OutputFile;
    }

    if (pMergeOption->fRestoreFileName) pInfo->Flags |= MERGE_FLAG_RESTORE_NAME;

    if (!QueueUserWorkItem((LPTHREAD_START_ROUTINE)MergeWorkCallback, pInfo, WT_EXECUTEDEFAULT))
    {
        delete pInfo;
        return BSERR_QUEUE_USER_WORD_ITEM;
    }

    return BSERR_SUCCESS;
}

Long CModelSplitter::VeirfyIsFirstFile(PCTChar pszFile, PInt32 pFlags)
{
    CFileDisk file;
    BS_PART_FILE_HEADER_FIRST FileHeader;

    if (pFlags == NULL)
        return BSERR_INVALID_PARAM;

    *pFlags = 0;

    if (!file.Open(pszFile))
        return BSERR_OPEN_FILE;

    if (file.GetSize() < sizeof(BS_PART_FILE_HEADER))
        return BSERR_INVALID_FILE_SIZE;

    if (!file.Read(&FileHeader, sizeof(FileHeader)))
        return BSERR_READ_FILE;

    if (FileHeader.Magic != BS_FILE_HEADER_MAGIC)
        return BSERR_INVALID_FORMAT;

    if (!TEST_BITS(FileHeader.Flags, SPLIT_FLAG_FIRST_FILE))
        return BSERR_MERGE_NOT_FIRST;

    *pFlags = FileHeader.Flags & (SPLIT_FLAG_ENCRYPT | SPLIT_FLAG_SAVE_ORIG_NAME);

    return BSERR_SUCCESS;
}

// for LZMA

EXTC void* MyAlloc(size_t size)
{
    return HeapAlloc(CMem::GetGlobalHeap(), 0, size);
}

EXTC void MyFree(void *address)
{
    HeapFree(CMem::GetGlobalHeap(), 0, address);
}

/************************************************************************/
/* merge                                                                */
/************************************************************************/

ULong STDCALL CModelSplitter::MergeWorkCallback(MERGE_WORK_THREAD_INFO *pInfo)
{
    UInt32 OSMajorVersion = GetVersion() & 0xFF;

    if (OSMajorVersion < 6)
        return pInfo->This->MergeWorkNT5(pInfo);
    else
        return pInfo->This->MergeWorkNT6(pInfo);
}

ULong CModelSplitter::MergeWorkNT6(MERGE_WORK_THREAD_INFO *pInfo)
{
    return MergeWorkNT5(pInfo);
}

ULong CModelSplitter::MergeWorkNT5(MERGE_WORK_THREAD_INFO *pInfo)
{
    Long                      Status;
    PVoid                     pvBuffer, pvBufferDecompress;
    UInt32                    Key[8], PwdHash[4], Hash[8];
    sha256_ctx                s_ctx;
    aes_encrypt_ctx           aes_ctx;
    BS_PART_FILE_HEADER       FileHeader;
    BS_PART_FILE_HEADER_FIRST FileHeaderFirst;

    CFileDisk file, fileout;

    const SizeT MergeBufferSize = 64 * MEMORY_PAGE_SIZE;       // 256 KB
    const SizeT MergeDecompressBufferSize = MergeBufferSize * 2;

#define SHOW_MSG(...)    pInfo->pfShowErrorMessage(pInfo->CallbackParam, __VA_ARGS__)
#define SHOW_STATUS(Status, Info) pInfo->pfShowStatusMessage((pInfo->CallbackParam), (Status), (PCTChar)(Info))

    if (!file.Open(pInfo->InputFile))
    {
        SHOW_STATUS(BSERR_OPEN_FILE, pInfo->InputFile);
        goto _Exit;
    }

    if (!file.Read(&FileHeaderFirst, sizeof(FileHeaderFirst)))
    {
        SHOW_STATUS(BSERR_READ_FILE, pInfo->InputFile);
        goto _Exit;
    }

    if (FileHeaderFirst.Magic != BS_FILE_HEADER_MAGIC)
    {
        SHOW_STATUS(BSERR_INVALID_FORMAT, pInfo->InputFile);
        goto _Exit;
    }

    if (!TEST_BITS(FileHeaderFirst.Flags, SPLIT_FLAG_FIRST_FILE))
    {
        SHOW_STATUS(BSERR_MERGE_NOT_FIRST, pInfo->InputFile);
        goto _Exit;
    }

    if (TEST_BITS(FileHeaderFirst.Flags, SPLIT_FLAG_ENCRYPT))
    {
        if (pInfo->Password.IsEmpty())
        {
            SHOW_STATUS(BSERR_MERGE_INVALID_PASSWORD, NULL);
            goto _Exit;
        }

        InitKey(&aes_ctx, Key, PwdHash, 0, pInfo->Password, pInfo->Password.GetLength() * sizeof(WChar));
        Decrypt(&aes_ctx, &FileHeaderFirst.Parts, sizeof(FileHeaderFirst) - sizeof(FileHeader), Key);
        if (memcmp(FileHeaderFirst.PasswordHash, PwdHash, sizeof(PwdHash)))
        {
            SHOW_STATUS(BSERR_MERGE_INVALID_PASSWORD, NULL);
            goto _Exit;
        }
    }

    pvBuffer            = NULL;
    pvBufferDecompress  = NULL;
    Status              = BSERR_NORMAL;

    LOOP_ONCE()
    {
        if (TEST_BITS(pInfo->Flags, MERGE_FLAG_RESTORE_NAME) &&
            TEST_BITS(FileHeaderFirst.Flags, SPLIT_FLAG_SAVE_ORIG_NAME) &&
            FileHeaderFirst.FileNameLength != 0)
        {
            FileHeaderFirst.OriginalFileName[FileHeaderFirst.FileNameLength] = 0;
            pInfo->OutputFile.ReplaceFileName(FileHeaderFirst.OriginalFileName);
        }

        if (IsPathExists(pInfo->OutputFile))
        {
            if (!pInfo->pfShowAskMessage(
                    pInfo->CallbackParam,
                    _T("%s\n%s"),
                    (PCTChar)pInfo->OutputFile,
                    BS_ERR_STRING_CONFIRM_TO_OVERWRITE))
                break;
        }
        pvBuffer = VirtualAllocEx(
            NtCurrentProcess(),
            NULL,
            MergeBufferSize,
            MEM_RESERVE|MEM_COMMIT,
            PAGE_READWRITE);
        if (pvBuffer == NULL)
        {
            SHOW_STATUS(BSERR_OUT_OF_MEMORY, NULL);
            break;
        }

        if (TEST_BITS(FileHeaderFirst.Flags, SPLIT_FLAG_COMPRESS))
        {
            pvBufferDecompress = VirtualAllocEx(
                NtCurrentProcess(),
                0,
                MergeDecompressBufferSize,
                MEM_RESERVE|MEM_COMMIT,
                PAGE_READWRITE);
            if (pvBufferDecompress == NULL)
            {
                SHOW_STATUS(BSERR_OUT_OF_MEMORY, NULL);
                break;
            }
        }

        if (!fileout.Create(pInfo->OutputFile))
        {
            SHOW_STATUS(BSERR_CREATE_FILE, pInfo->OutputFile);
            break;
        }

        UInt32 Index = 0;
        ULarge_Integer PartSize, AlignedSize, FileSize, BytesProcessed;

        FileSize.LowPart = sizeof(FileHeaderFirst) - sizeof(FileHeaderFirst.OriginalFileName) - sizeof(FileHeaderFirst.FileNameLength);;
        if (TEST_BITS(FileHeaderFirst.Flags, SPLIT_FLAG_SAVE_ORIG_NAME))
             FileSize.LowPart += sizeof(FileHeaderFirst.FileNameLength) + FileHeaderFirst.FileNameLength * sizeof(WChar);

        file.Seek(file.FILE_SEEK_BEGIN, FileSize.LowPart);
        PartSize.LowPart = file.GetSize(&PartSize.HighPart);
        PartSize.QuadPart -= FileSize.LowPart;
        FileSize.QuadPart = FileHeaderFirst.FileSize;
        BytesProcessed.QuadPart = 0;

        FileHeader = *(BS_PART_FILE_HEADER *)&FileHeaderFirst;

        LOOP_ALWAYS()
        {
            TChar szSuffix[25];

            if (PartSize.QuadPart == 0)
            {
                SHOW_STATUS(BSERR_INVALID_FILE_SIZE, pInfo->InputFile);
                goto _Error;
            }

            sha256_init(&s_ctx);
            InitKey(&aes_ctx, Key, PwdHash, Index, pInfo->Password, pInfo->Password.GetLength() * sizeof(WChar));

            AlignedSize.QuadPart = ROUND_DOWN(PartSize.QuadPart, MergeBufferSize);
            PartSize.QuadPart   -= AlignedSize.QuadPart;

            do
            {
                if (!file.Read(pvBuffer, MergeBufferSize))
                {
                    SHOW_STATUS(BSERR_READ_FILE, pInfo->InputFile);
                    goto _Error;
                }

                sha256_update(&s_ctx, (PByte)pvBuffer, MergeBufferSize);

                if (TEST_BITS(FileHeader.Flags, SPLIT_FLAG_ENCRYPT))
                    Decrypt(&aes_ctx, pvBuffer, MergeBufferSize, Key);

                if (TEST_BITS(FileHeader.Flags, SPLIT_FLAG_COMPRESS))
                {
                    // not implemented
                }

                if (!fileout.Write(pvBuffer, MergeBufferSize))
                {
                    SHOW_STATUS(BSERR_WRITE_FILE, pInfo->OutputFile);
                    goto _Error;
                }

                BytesProcessed.QuadPart += MergeBufferSize;
                if (!pInfo->pfShowStatus(pInfo->CallbackParam, &BytesProcessed, &FileSize))
                    goto _ForceStop;

                AlignedSize.QuadPart -= MergeBufferSize;
            } while (AlignedSize.QuadPart != 0);

            if (PartSize.LowPart != 0)
            {
                if (!file.Read(pvBuffer, PartSize.LowPart))
                {
                    SHOW_STATUS(BSERR_READ_FILE, pInfo->InputFile);
                    goto _Error;
                }

                sha256_update(&s_ctx, (PByte)pvBuffer, PartSize.LowPart);

                if (TEST_BITS(FileHeader.Flags, SPLIT_FLAG_ENCRYPT))
                    Decrypt(&aes_ctx, pvBuffer, PartSize.LowPart, Key);

                if (!fileout.Write(pvBuffer, PartSize.LowPart))
                {
                    SHOW_STATUS(BSERR_WRITE_FILE, pInfo->OutputFile);
                    goto _Error;
                }

                BytesProcessed.QuadPart += PartSize.LowPart;
                if (!pInfo->pfShowStatus(pInfo->CallbackParam, &BytesProcessed, &FileSize))
                    goto _ForceStop;
            }

            sha256_final(&s_ctx, (PByte)Hash);
            if (memcmp(Hash, FileHeader.DataHash, sizeof(Hash)))
            {
                SHOW_STATUS(BSERR_MERGE_PART_FILE_CORRUPT, pInfo->InputFile);
                break;
            }

            if (++Index == FileHeaderFirst.Parts)
            {
                Status = BSERR_SUCCESS;
                break;
            }

            FormatString(szSuffix, _T(".%s%d"), PART_FILE_SUFFIX, Index);
            pInfo->InputFile.ReplaceExtension(szSuffix);
            if (!file.Open(pInfo->InputFile))
            {
                SHOW_STATUS(BSERR_OPEN_FILE, pInfo->InputFile);
                break;
            }

            if (!file.Read(&FileHeader, sizeof(FileHeader)))
            {
                SHOW_STATUS(BSERR_READ_FILE, pInfo->InputFile);
                goto _Error;
            }

            PartSize.QuadPart = file.GetSize() - sizeof(FileHeader);
        }
    }

_ForceStop:
_Error:

    fileout.Close();
    file.Close();
    if (BS_FAILED(Status))
        DeleteFile(pInfo->OutputFile);

    if (pvBuffer)           VirtualFreeEx(NtCurrentProcess(), pvBuffer,           0, MEM_RELEASE);
    if (pvBufferDecompress) VirtualFreeEx(NtCurrentProcess(), pvBufferDecompress, 0, MEM_RELEASE);

_Exit:
    pInfo->pfShowStatus(pInfo->CallbackParam, NULL, NULL);
    delete pInfo;

    return 0;

#undef SHOW_MSG
#undef SHOW_STATUS

}

/************************************************************************/
/* split                                                                */
/************************************************************************/

ULong STDCALL CModelSplitter::SplitWorkCallback(SPLIT_WORK_THREAD_INFO *pInfo)
{
    UInt32 OSMajorVersion = GetVersion() & 0xFF;
    if (OSMajorVersion < 6)
        return pInfo->This->SplitWorkNT5(pInfo);
    else
        return pInfo->This->SplitWorkNT6(pInfo);
}

ULong CModelSplitter::SplitWorkNT6(SPLIT_WORK_THREAD_INFO *pInfo)
{
    return SplitWorkNT5(pInfo);
}

ULong CModelSplitter::SplitWorkNT5(SPLIT_WORK_THREAD_INFO *pInfo)
{
    return 0;
}

#if 0
void unused_func()
{
    Bool   LoopOnce, bForceStop;
    HANDLE hFileIn, hFileOut;
    PVoid  pvBuffer, pvBuffer1, pvBuffer2, pvBufferCompress;

    UInt32              Index;
    TChar               szPath[MAX_PATH + 20];
    LARGE_INTEGER       BeginOffset, EndOffset;
    OVERLAPPED          OverlappedRead, OverlappedWrite;
    union
    {
        BS_PART_FILE_HEADER       FileHeader;
        BS_PART_FILE_HEADER_FIRST FileHeaderFirst;
    };

    Bool            bAlwaysLoop;
    DWORD           BytesTransfered, BytesToWrite, BytesToRead;
    ULONG_PTR       CompletionKey;
    LPOVERLAPPED    pOverlaped;
    LARGE_INTEGER   Offset, FileSizeRemain;
    UInt32          Hash[8];
    sha256_ctx      sha256_context;
    aes_encrypt_ctx aes_context;

    const SizeT SplitBufferSize = 64 * MEMORY_PAGE_SIZE;       // 256 KB
    const SizeT SplitCompressBufferSize = SplitBufferSize * 2;

    pvBuffer1        = NULL;
    pvBuffer2        = NULL;
    pvBufferCompress = NULL;
    LoopOnce         = False;
    bForceStop       = False;
    hFileIn          = INVALID_HANDLE_VALUE;
    hFileOut         = INVALID_HANDLE_VALUE;

    do
    {
        pvBuffer1 = VirtualAllocEx(
                        NtCurrentProcess(),
                        NULL,
                        SplitBufferSize,
                        MEM_RESERVE|MEM_COMMIT,
                        PAGE_READWRITE);
        if (pvBuffer1 == NULL)
            break;

        pvBuffer2 = VirtualAllocEx(
                        NtCurrentProcess(),
                        NULL,
                        SplitBufferSize,
                        MEM_RESERVE|MEM_COMMIT,
                        PAGE_READWRITE);
        if (pvBuffer2 == NULL)
            break;

        if (pInfo->Flags & SPLIT_FLAG_COMPRESS)
        {
            pvBufferCompress = VirtualAllocEx(
                                   NtCurrentProcess(),
                                   NULL,
                                   SplitCompressBufferSize,
                                   MEM_RESERVE|MEM_COMMIT,
                                   PAGE_READWRITE);
            if (pvBufferCompress == NULL)
                break;
        }

        CIoCompletionPort IoCompletionPort;

        if (!IoCompletionPort.Create(1))
            break;

        hFileIn = CreateFile(
                      pInfo->InputFile,
                      GENERIC_READ,
                      FILE_SHARE_READ,
                      NULL,
                      OPEN_EXISTING,
                      FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OVERLAPPED,
                      NULL);

        Index = _InterlockedIncrement(&pInfo->CurrentThreadIndex) - 1;

        FileHeader.Flags = pInfo->Flags;

        if (Index == 0)
        {
            SetEvent(pInfo->hEventFirstSignal);
            FileHeader.Flags |= SPLIT_FLAG_FIRST_FILE;
            FileHeaderFirst.Parts = pInfo->Parts;
            FileHeaderFirst.FileSize = pInfo->FileSize.QuadPart;
        }
        else if (Index + 1 == pInfo->Parts)
        {
            FileHeader.Flags |= SPLIT_FLAG_LAST_FILE;
        }

        if (hFileIn == INVALID_HANDLE_VALUE)
            break;

        GenerateOutputFileName(pInfo->OutputFile, szPath, Index);

        hFileOut = CreateFile(
                       szPath,
                       GENERIC_WRITE,
                       FILE_SHARE_READ,
                       NULL,
                       CREATE_ALWAYS,
                       FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OVERLAPPED,
                       NULL);
        if (hFileOut == INVALID_HANDLE_VALUE)
            break;

        if (!IoCompletionPort.AssociateDevice(hFileIn, BS_IOCP_KEY_READ))
            break;

        if (!IoCompletionPort.AssociateDevice(hFileOut, BS_IOCP_KEY_WRITE))
            break;

        FileHeader.Magic = BS_FILE_HEADER_MAGIC;
        FileHeaderFirst.FileNameLength = 0;

        if (TEST_BITS(FileHeader.Flags, SPLIT_FLAG_FIRST_FILE) &&
            TEST_BITS(FileHeader.Flags, SPLIT_FLAG_SAVE_ORIG_NAME))
        {
            PTChar pszFileName = findname(pInfo->InputFile);

#if defined(UNICODE) || defined(_UNICODE)
            FileHeaderFirst.FileNameLength = StrLengthW(pszFileName);
            CopyMemory(FileHeaderFirst.OriginalFileName, pszFileName, FileHeaderFirst.FileNameLength * sizeof(WChar));
#else
            FileHeaderFirst.FileNameLength =
                MultiByteToWideChar(
                    CP_ACP,
                    0,
                    pszFileName,
                    -1,
                    FileHeaderFirst.OriginalFileName,
                    countof(FileHeaderFirst.OriginalFileName)) - 1;
#endif
        }

        Offset.QuadPart = sizeof(FileHeader);

        if (TEST_BITS(FileHeader.Flags, SPLIT_FLAG_FIRST_FILE))
        {
            BeginOffset.QuadPart = 0;
            EndOffset.QuadPart   = pInfo->FirstPartSliceInByte.QuadPart;
            Offset.QuadPart     += pInfo->FirstPartOverhead;
        }
        else
        {
            BeginOffset.QuadPart  = pInfo->FirstPartSliceInByte.QuadPart;
            BeginOffset.QuadPart += pInfo->SpliceSizeInByte.QuadPart * (Index - 1);
            EndOffset.QuadPart = BeginOffset.QuadPart + pInfo->SpliceSizeInByte.QuadPart;
        }

        if (EndOffset.QuadPart > pInfo->FileSize.QuadPart)
            EndOffset.QuadPart = pInfo->FileSize.QuadPart;

        OverlappedRead.Offset      = BeginOffset.LowPart;
        OverlappedRead.OffsetHigh  = BeginOffset.HighPart;
        OverlappedRead.hEvent      = NULL;
        OverlappedWrite.hEvent     = NULL;
        OverlappedWrite.Offset     = Offset.LowPart;
        OverlappedWrite.OffsetHigh = Offset.HighPart;

        FileSizeRemain.QuadPart = EndOffset.QuadPart - BeginOffset.QuadPart;

        FileHeader.PartOriginalSize = FileSizeRemain.QuadPart;

        sha256_init(&sha256_context);

        if ((FileHeader.Flags & SPLIT_FLAG_ENCRYPT) && !pInfo->Password.IsEmpty())
        {
            InitKey(
                &aes_context,
                Hash,
                FileHeaderFirst.PasswordHash,
                Index,
                (PWChar)pInfo->Password,
                pInfo->Password.GetLength() * sizeof(WChar));
        }

        bAlwaysLoop  = True;
        pvBuffer     = NULL;
        BytesToWrite = 0;

        BytesToRead = min(SplitBufferSize, FileSizeRemain.LowPart);
        ReadFile(hFileIn, pvBuffer1, BytesToRead, NULL, &OverlappedRead);

        while (bAlwaysLoop)
        {
            if (!IoCompletionPort.GetStatus(&CompletionKey, &BytesTransfered, &pOverlaped))
                break;

            if (CompletionKey == BS_IOCP_KEY_READ)
            {
                Bool bContinue;
                if (BytesToWrite != 0)
                {
                    IoCompletionPort.PostStatus(CompletionKey, BytesTransfered, pOverlaped);
                    continue;
                }

                EnterCriticalSection(&pInfo->cs);
                pInfo->BytesProcessed.QuadPart += BytesTransfered;
                bContinue = pInfo->pfShowStatus(pInfo->CallbackParam, &pInfo->BytesProcessed, &pInfo->FileSize);
                LeaveCriticalSection(&pInfo->cs);
                if (!bContinue)
                {
                    bForceStop = True;
                    break;
                }

                pvBuffer     = pvBuffer1;
                BytesToWrite = BytesTransfered;

                FileSizeRemain.QuadPart -= BytesTransfered;

                if (FileSizeRemain.QuadPart > 0)
                {
                    BeginOffset.QuadPart  += BytesTransfered;

                    pOverlaped->Offset     = BeginOffset.LowPart;
                    pOverlaped->OffsetHigh = BeginOffset.HighPart;

                    Swap(pvBuffer1, pvBuffer2);
                    BytesToRead = min(SplitBufferSize, FileSizeRemain.LowPart);
                    ReadFile(hFileIn, pvBuffer1, BytesToRead, NULL, pOverlaped);
                }

                if (BytesToWrite != 0)
                {
/*
                    if (TEST_BITS(FileHeader.Flags, SPLIT_FLAG_COMPRESS))
                    {
                        Int   Result;
                        PBS_BLOCK_DATA pBlockData;

                        pBlockData = (PBS_BLOCK_DATA)pvBufferCompress;
                        pBlockData->BlockSize = SplitCompressBufferSize;

                        Result = Lzma86_Encode(
                                     pBlockData->Data,
                                     (PSizeT)&pBlockData->BlockSize,
                                     (PByte)pvBuffer,
                                     BytesToWrite,
                                     9,
                                     1 << 23,
                                     2);
                        if (Result != SZ_OK)
                        {
                            pInfo->MessageCallback(
                                pInfo->CallbackParam,
                                _T("Lzma86_Encode() failed, thread index = %d"),
                                Index);
                            break;
                        }

                        pvBuffer = pBlockData;
                        BytesToWrite = pBlockData->BlockSize + sizeof(pBlockData->BlockSize);
                    }
*/
                    if (TEST_BITS(FileHeader.Flags, SPLIT_FLAG_ENCRYPT))
                        Encrypt(&aes_context, pvBuffer, BytesToWrite, Hash);

                    sha256_update(&sha256_context, (PByte)pvBuffer, BytesToWrite);
                    WriteFile(hFileOut, pvBuffer, BytesToWrite, NULL, &OverlappedWrite);
                }
            }
            else // if (CompletionKey == SPLIT_IOCP_KEY_WRITE)
            {
                if (FileSizeRemain.QuadPart > 0)
                {
                    BytesToWrite     = 0;
                    Offset.LowPart   = pOverlaped->Offset;
                    Offset.HighPart  = pOverlaped->OffsetHigh;
                    Offset.QuadPart += BytesTransfered;

                    pOverlaped->Offset     = Offset.LowPart;
                    pOverlaped->OffsetHigh = Offset.HighPart;
                    continue;
                }

                sha256_final(&sha256_context, (PByte)FileHeader.DataHash);

                OverlappedWrite.Offset = 0;
                OverlappedWrite.OffsetHigh = 0;

                if (TEST_BITS(FileHeader.Flags, SPLIT_FLAG_FIRST_FILE))
                {
                    UInt32 HeaderSize;

                    HeaderSize = GetStructMemberOffset(BS_PART_FILE_HEADER_FIRST, Magic, FileNameLength);
                    if (TEST_BITS(FileHeaderFirst.Flags, SPLIT_FLAG_SAVE_ORIG_NAME))
                    {
                        UInt32 ExtraLength = sizeof(FileHeaderFirst.FileNameLength) + FileHeaderFirst.FileNameLength * sizeof(WChar);
                        HeaderSize += ExtraLength;
                    }

                    if (TEST_BITS(FileHeaderFirst.Flags, SPLIT_FLAG_ENCRYPT))
                        Encrypt(&aes_context, &FileHeaderFirst.Parts, HeaderSize - sizeof(FileHeader), &Hash[4]);

                    WriteFile(hFileOut, &FileHeaderFirst, HeaderSize, NULL, &OverlappedWrite);
                }
                else
                {
                    WriteFile(hFileOut, &FileHeader, sizeof(FileHeader), NULL, &OverlappedWrite);
                }

                IoCompletionPort.GetStatus(&CompletionKey, &BytesTransfered, &pOverlaped);
                break;
            }
        }

    } while (LoopOnce);

    if (pvBuffer1)        VirtualFreeEx(NtCurrentProcess(), pvBuffer1,        0, MEM_RELEASE);
    if (pvBuffer2)        VirtualFreeEx(NtCurrentProcess(), pvBuffer2,        0, MEM_RELEASE);
    if (pvBufferCompress) VirtualFreeEx(NtCurrentProcess(), pvBufferCompress, 0, MEM_RELEASE);

    if (hFileIn  != INVALID_HANDLE_VALUE) CloseHandle(hFileIn);
    if (hFileOut != INVALID_HANDLE_VALUE) CloseHandle(hFileOut);

    if (bForceStop)
        DeleteFile(szPath);

    if (_InterlockedDecrement(&pInfo->RefCount) == 0)
    {
        pInfo->pfShowStatus(pInfo->CallbackParam, NULL, NULL);
        DeleteCriticalSection(&pInfo->cs);
        delete pInfo;
    }

    return 0;
}

#endif

Void CModelSplitter::InitKey(aes_encrypt_ctx *aes_context, UInt32 (Key)[8], UInt32 (PwdHash)[4], UInt32 Index, PCWChar pszPassword, SizeT cbSize)
{
    sha256((PByte)pszPassword, cbSize, (PByte)Key);

    ++Index;
    Key[0] = _rotl(Key[0], Index);
    Key[1] = _rotl(Key[1], Index);
    Key[2] = _rotl(Key[2], Index);
    Key[3] = _rotl(Key[3], Index);

    aes_encrypt_key128(&Key[4], aes_context);

    PwdHash[0] = Key[0] ^ Key[4];
    PwdHash[1] = Key[1] ^ Key[5];
    PwdHash[2] = Key[2] ^ Key[6];
    PwdHash[3] = Key[3] ^ Key[7];

    Key[4] = Key[0];
    Key[5] = Key[1];
    Key[6] = Key[2];
    Key[7] = Key[3];
}

Void CModelSplitter::Encrypt(aes_encrypt_ctx *aes_context, PVoid pvBuffer, SizeT Size, PVoid pvKey)
{
    SizeT   AlignedSize;
    PByte   pbBuffer = (PByte)pvBuffer;
    PUInt32 pKey = (PUInt32)pvKey;

    AlignedSize = ROUND_DOWN(Size, 16);
    for (SizeT s = AlignedSize; s != 0; s -= 16)
    {
        aes_encrypt(pKey, pKey, aes_context);

        pKey[0] = *((PUInt32)pbBuffer + 0) ^= pKey[0];
        pKey[1] = *((PUInt32)pbBuffer + 1) ^= pKey[1];
        pKey[2] = *((PUInt32)pbBuffer + 2) ^= pKey[2];
        pKey[3] = *((PUInt32)pbBuffer + 3) ^= pKey[3];

        pbBuffer += 16;
    }

    if (Size -= AlignedSize)
    {
        Byte Buffer[16];

        CopyMemory(Buffer, pbBuffer, Size);
//        ZeroMemory(Buffer + Size, sizeof(Buffer) - Size);

        aes_encrypt(pKey, pKey, aes_context);

        pKey[0] = *((PUInt32)Buffer + 0) ^= pKey[0];
        pKey[1] = *((PUInt32)Buffer + 1) ^= pKey[1];
        pKey[2] = *((PUInt32)Buffer + 2) ^= pKey[2];
        pKey[3] = *((PUInt32)Buffer + 3) ^= pKey[3];

        CopyMemory(pbBuffer, Buffer, Size);
    }
}

Void CModelSplitter::Decrypt(aes_encrypt_ctx *aes_context, PVoid pvBuffer, SizeT Size, PVoid pvKey)
{
    SizeT   AlignedSize;
    PByte   pbBuffer = (PByte)pvBuffer;
    PUInt32 pKey = (PUInt32)pvKey;

    AlignedSize = ROUND_DOWN(Size, 16);
    for (SizeT s = AlignedSize; s != 0; s -= 16)
    {
        aes_encrypt(pKey, pKey, aes_context);

        Swap(((PUInt32)pbBuffer)[0], pKey[0]);
        Swap(((PUInt32)pbBuffer)[1], pKey[1]);
        Swap(((PUInt32)pbBuffer)[2], pKey[2]);
        Swap(((PUInt32)pbBuffer)[3], pKey[3]);

        *((PUInt32)pbBuffer + 0) ^= pKey[0];
        *((PUInt32)pbBuffer + 1) ^= pKey[1];
        *((PUInt32)pbBuffer + 2) ^= pKey[2];
        *((PUInt32)pbBuffer + 3) ^= pKey[3];

        pbBuffer += 16;
    }

    if (Size -= AlignedSize)
    {
        Byte Buffer[16];

        CopyMemory(Buffer, pbBuffer, Size);
//        ZeroMemory(Buffer + Size, sizeof(Buffer) - Size);

        aes_encrypt(pKey, pKey, aes_context);

        Swap(((PUInt32)Buffer)[0], pKey[0]);
        Swap(((PUInt32)Buffer)[1], pKey[1]);
        Swap(((PUInt32)Buffer)[2], pKey[2]);
        Swap(((PUInt32)Buffer)[3], pKey[3]);

        *((PUInt32)Buffer + 0) ^= pKey[0];
        *((PUInt32)Buffer + 1) ^= pKey[1];
        *((PUInt32)Buffer + 2) ^= pKey[2];
        *((PUInt32)Buffer + 3) ^= pKey[3];

        CopyMemory(pbBuffer, Buffer, Size);
    }
}