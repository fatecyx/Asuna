#include "ControllerSplitter.h"

Int CControllerSplitter::Execute(HINSTANCE hInstance /* = NULL */)
{
    Int Result;

    if (!IsViewAttached() || !IsModelAttached())
        return -1;

    InitializeCriticalSectionAndSpinCount(&m_csSetProgress, 4000);

    m_pView->SetController(this);
    Result = m_pView->Run(hInstance);

    DeleteCriticalSection(&m_csSetProgress);

    return Result;
}

Bool CDECL CControllerSplitter::ShowErrorMessage(ULong_Ptr Param, PCTChar pszFormat, ...)
{
    va_list args;
    CControllerSplitter *This;

    va_start(args, Param);
    This = (CControllerSplitter *)Param;
    return This->ShowErrorMessageInternal(pszFormat, args);
}

Bool CDECL CControllerSplitter::ShowAskMessage(ULong_Ptr Param, PCTChar pszFormat, ...)
{
    va_list args;
    CControllerSplitter *This;

    va_start(args, pszFormat);
    This = (CControllerSplitter *)Param;
    return This->m_pView->ShowAskMessageV(pszFormat, args) == IDOK;
}

Bool CControllerSplitter::ShowErrorMessageInternal(PCTChar pszFormat, va_list args)
{
    m_pView->ShowErrorMessageV(pszFormat, args);
    return True;
}

Bool STDCALL CControllerSplitter::ShowErrorMessageByStatus(ULong_Ptr Param, Long Status, PCTChar pszInfo)
{
    CControllerSplitter *This;
    This = (CControllerSplitter *)Param;
    return This->ShowErrMsgWithStatusInternal(Status, pszInfo);
}

Bool CControllerSplitter::ShowErrMsgWithStatusInternal(Long Status, PCTChar pszInfo)
{
    if (pszInfo != NULL)
        m_pView->ShowErrorMessage(_T("%s\n%s"), pszInfo, MapModelErrorToControllerMessage(Status));
    else
        m_pView->ShowErrorMessage(_T("%s"), MapModelErrorToControllerMessage(Status));
    return True;
}

Bool
STDCALL
CControllerSplitter::
ShowStatus(
    ULong_Ptr      Param,
    PULarge_Integer pBytesProcessed,
    PULarge_Integer pFileSize
)
{
    CControllerSplitter *This = (CControllerSplitter *)Param;
    return This->ShowStatusInternal(pBytesProcessed, pFileSize);
}

Bool
CControllerSplitter::
ShowStatusInternal(
    PULarge_Integer pBytesProcessed,
    PULarge_Integer pFileSize
)
{
    if (pBytesProcessed == NULL || pFileSize == NULL)
        return m_pView->SetOperationComplete(True);

    return m_pView->SetProgress((pBytesProcessed->QuadPart - 1) * 100 / pFileSize->QuadPart + 1);
}

Bool CControllerSplitter::Split()
{
    Long  Status, OutputLength;
    Int64 SliceSize;
    TChar szInptut[MAX_PATH + 20], szOutput[MAX_PATH + 20], szPassword[MAX_PASSWORD_LENGTH];

    SliceSize = m_pView->GetSliceSize();
    if (SliceSize == 0)
    {
        m_pView->ShowErrorMessage(CTRL_ERR_STRING_INVALID_SLICE_SIZE);
        return False;
    }

    if (m_pView->GetInputFileName(szInptut, countof(szInptut)) == 0 || GetFileAttributes(szInptut) == -1)
    {
        m_pView->ShowErrorMessage(CTRL_ERR_STRING_INVALID_INPUT_NAME);
        return False;
    }

    OutputLength = m_pView->GetOutputFileName(szOutput, countof(szOutput));

    Status = m_pModel->VerifyIsOutputFileExist(szInptut, szOutput, countof(szInptut), SliceSize);
    if (Status == BSERR_OPEN_FILE)
    {
        m_pView->ShowErrorMessage(_T("%s\n%s"), szInptut, MapModelErrorToControllerMessage(Status));
        return False;
    }
    else if (Status == BSERR_NORMAL)
    {
        if (m_pView->ShowAskMessage(_T("%s\n%s"), szOutput, CTRL_ERR_STRING_OUTPUT_ALREADY_EXIST_ASK) != IDOK)
            return False;
    }
    else if (BS_FAILED(Status))
    {
        m_pView->ShowErrorMessage(_T("%s"), MapModelErrorToControllerMessage(Status));
        return False;
    }

    SPLIT_OPTION option;

    szOutput[OutputLength] = 0;

    option.fSaveFileName        = m_pView->IsSaveOriginalFileName();
    option.fCompress            = m_pView->IsOutputCompress();
    option.fEncrypt             = m_pView->IsOutputEncrypt();
    option.InputFile            = szInptut;
    option.OutputFile           = szOutput;
    option.pfShowStatus         = ShowStatus;
    option.pfShowErrorMessage   = ShowErrorMessage;
    option.pfShowAskMessage     = ShowAskMessage;
    option.pfShowStatusMessage  = ShowErrorMessageByStatus;
    option.CallbackParam        = (ULong_Ptr)this;

    if (option.fEncrypt)
    {
        m_pView->GetPassword(szPassword, countof(szPassword));
        option.Password = szPassword;
    }

    option.SpliceSizeInByte.QuadPart = SliceSize;

    Status = m_pModel->Split(&option);
    if (BS_FAILED(Status))
    {
        m_pView->ShowErrorMessage(_T("%s"), MapModelErrorToControllerMessage(Status));
        return False;
    }

    m_pView->SetOperationComplete(False);

    return True;
}

Bool CControllerSplitter::Merge()
{
    Long Status;
    union
    {
        TChar szInptut[MAX_PATH + 20];
        TChar szOutput[MAX_PATH + 20];
        TChar szPassword[MAX_PASSWORD_LENGTH];
    };

    if (m_pView->GetInputFileName(szInptut, countof(szInptut)) == 0 || GetFileAttributes(szInptut) == -1)
    {
        m_pView->ShowErrorMessage(CTRL_ERR_STRING_INVALID_INPUT_NAME);
        return False;
    }

    MERGE_OPTION option;

    option.InputFile = szInptut;

    if (m_pView->GetOutputFileName(szOutput, countof(szOutput)) != 0)
        option.OutputFile = szOutput;

    if (m_pView->GetPassword(szPassword, countof(szPassword)) != 0)
        option.Password = szPassword;

    option.fRestoreFileName     = m_pView->IsRestoreOriginalFileName();
    option.pfShowStatus         = ShowStatus;
    option.pfShowErrorMessage   = ShowErrorMessage;
    option.pfShowAskMessage     = ShowAskMessage;
    option.pfShowStatusMessage  = ShowErrorMessageByStatus;
    option.CallbackParam        = (ULong_Ptr)this;

    Status = m_pModel->Merge(&option);
    if (BS_FAILED(Status))
    {
        m_pView->ShowErrorMessage(_T("%s"), MapModelErrorToControllerMessage(Status));
        return False;
    }

    m_pView->SetOperationComplete(False);
    return True;
}

Bool CControllerSplitter::Open()
{
    Long  Status;
    Int32 Flags;
    TChar szPath[MAX_PATH];

    if (m_pView->GetInputFileName(szPath, countof(szPath)) == 0)
        return False;

    Status = m_pModel->VeirfyIsFirstFile(szPath, &Flags);
    if (BS_FAILED(Status))
    {
        m_pView->ShowErrorMessage(_T("%s"), MapModelErrorToControllerMessage(Status));
        return False;
    }

    m_pView->HasPassword(TEST_BITS(Flags, SPLIT_FLAG_ENCRYPT));
    m_pView->HasOriginalFileName(TEST_BITS(Flags, SPLIT_FLAG_SAVE_ORIG_NAME));

    return True;
}

PCTChar CControllerSplitter::MapModelErrorToControllerMessage(Long ErrorCode)
{
    static TChar *s_szErrMsg[] =
    {
        CTRL_ERR_STRING_UNKNOWN_ERROR,
        CRTL_ERR_STRING_FAILED_OPEN_FILE,
        CRTL_ERR_STRING_FAILED_CREATE_FILE,
        CRTL_ERR_STRING_FAILED_GET_SIZE,
        CRTL_ERR_STRING_FAILED_READ_FILE,
        CRTL_ERR_STRING_FAILED_WRITE_FILE,
        CRTL_ERR_STRING_FAILED_CLOSE_FILE,
        CRTL_ERR_STRING_FAILED_QUEUE_ITEM,
        CRTL_ERR_STRING_FAILED_OUT_OF_MEMORY,
        CRTL_ERR_STRING_FAILED_INVALID_PARAM,
        CRTL_ERR_STRING_FAILED_FILE_SIZE_ZERO,
        CRTL_ERR_STRING_FAILED_INVALID_SLICE_SIZE,
        CRTL_ERR_STRING_FAILED_INVALID_FILE_SIZE,
        CRTL_ERR_STRING_FAILED_INVALID_FORMAT,
        CRTL_ERR_STRING_FAILED_NOT_FIRST,
        CTRL_ERR_STRING_FAILED_INVALID_PASSWORD,
        CRTL_ERR_STRING_FAILED_PART_FILE_CORRUPT,
    };

    if (ErrorCode == BSERR_SUCCESS)
        return CRTL_ERR_STRING_NO_ERROR;

    ErrorCode -= BSERR_FIRST;
    if (ErrorCode >= countof(s_szErrMsg))
        return _T("");

    return s_szErrMsg[ErrorCode];
}