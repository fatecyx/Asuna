#pragma comment(linker,"/ENTRY:main")
#pragma comment(linker,"/MERGE:.text=.Hiromi /SECTION:.Hiromi,ERW")
#pragma comment(linker,"/MERGE:.rdata=.Hiromi")
#pragma comment(lib, "msvcrt6.lib")
#pragma comment(lib, "shlwapi.lib")

#include <stdio.h>
#include <malloc.h>
#include <memory.h>
#include <getmainargs.h>

#define RAW_SIZE_OFFSET		0x2
#define RAW_DATA_OFFSET		0xA
#define WEIGHT_OFFSET		0x12
#define HEIGHT_OFFSET		0x16
#define OUT_RAW_DATA_OFFSET	0x36

enum {BMP1, BMP2, BMPOUT};

void main(int argc, char **argv)
{
	getmainargs(&argc, &argv);

	if (argc != 4)
	{
		return;
	}

	FILE *fp[3];
	char			*cBuffer[3];
	char			*opentype[] = {"rb", "rb", "wb",};
	unsigned long	ulHeight[3], ulWeight[3], ulSize[3], ulRawOffset[2];

	for (char i = 0; i != sizeof(fp) / sizeof(*fp); ++i)
	{
		fp[i] = fopen(argv[i + 1], opentype[i]);
		if (fp[i] == NULL)
		{
			printf("Open \"%s\" failed.\n", argv[i + 1]);
			return;
		}
		fseek(fp[i], 0, SEEK_END);
		ulSize[i] = ftell(fp[i]);
		fseek(fp[i], 0, SEEK_SET);
		if (ulSize[i] != 0)
		{
			cBuffer[i] = (char *)malloc(ulSize[i]);
			fread(cBuffer[i], ulSize[i], 1, fp[i]);
			fseek(fp[i], 0, SEEK_SET);
			ulWeight[i] = *(unsigned long *)(cBuffer[i] + WEIGHT_OFFSET);
			ulHeight[i] = *(unsigned long *)(cBuffer[i] + HEIGHT_OFFSET);
			ulRawOffset[i] = *(unsigned long *)(cBuffer[i] + RAW_DATA_OFFSET);
			fclose(fp[i]);
		}
	}

	ulSize[BMPOUT] = ulSize[BMP1] - ulRawOffset[BMP1] + ulSize[BMP2] - ulRawOffset[BMP2];
	cBuffer[BMPOUT] = (char *)malloc(ulSize[BMPOUT]);
	memcpy(cBuffer[BMPOUT], cBuffer[BMP2], OUT_RAW_DATA_OFFSET);
	*(unsigned long *)(cBuffer[BMPOUT] + HEIGHT_OFFSET) += ulHeight[BMP1];
	*(unsigned long *)(cBuffer[BMPOUT] + RAW_DATA_OFFSET) = OUT_RAW_DATA_OFFSET;
	*(unsigned long *)(cBuffer[BMPOUT] + RAW_SIZE_OFFSET) = (ulSize[BMPOUT] += OUT_RAW_DATA_OFFSET);

	for (char i = BMP2, *p = cBuffer[BMPOUT] + OUT_RAW_DATA_OFFSET; i >= BMP1; --i)
	{
		memcpy(p, cBuffer[i] + ulRawOffset[i], ulSize[i] - ulRawOffset[i]);
		p += ulSize[i] - ulRawOffset[i];
	}

	fwrite(cBuffer[BMPOUT], ulSize[BMPOUT], 1, fp[BMPOUT]);

	for (char i = BMP1; i <= BMPOUT; ++i)
		free(cBuffer[i]);
	fclose(fp[BMPOUT]);
}