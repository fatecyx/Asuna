#pragma comment(linker,"/ENTRY:main")
#pragma comment(linker,"/MERGE:.text=.Kanade /SECTION:.Kanade,ERW")
#pragma comment(linker,"/MERGE:.rdata=.Kanade")
#pragma comment(linker,"/MERGE:.data=.Kanade")

#define USE_CRT_ALLOC

#include <Windows.h>
#include "crt_h.h"
#include "my_crt.h"
#include "my_common.h"
#include <bitset>

OVERLOAD_OP_NEW

#if 1

#define num 8
//unsigned num;
unsigned result,re;
bool diagonalP[num * 2 - 1],diagonalN[num * 2 - 1],Col[num],q[num][num];

FILE *out;

void GenerateChart(const unsigned &Row)
{
	if (!Row) return;
	HANDLE StdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	PChar begin,end,separator;
	COORD coord;
	coord.X = 0;
	coord.Y = 0;
	SetConsoleCursorPosition(StdOut,coord);
	for (unsigned c,r = 0;r != Row * 2 + 1;++r)
	{
		c = 1;
		if (r % 2 == 0)
        {
            if (r == 0)
            {
                begin = "��";
                separator = "����";
                end = "����";
            }
			else if (r == Row * 2)
            {
                begin = "��";
                separator = "����";
                end = "����";
            }
			else
            {
                begin = "��";
                separator = "����";
                end = "����";
            }
        }
		else
        {
            begin = "��";
            separator = "����";
            end = "����";
        }

		printf("%s",begin);
		while (c++ != Row)
			printf("%s",separator);
		printf("%s\t\n",end,r);
	}
}

void Move(unsigned Y, unsigned X, unsigned Row, bool remove = 0)
{
	HANDLE StdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD coord;
	coord.X = (X * 2 -1) * 2;
	coord.Y = Y * 2 - 1/* + result * (2 * num + 1)*/;
	SetConsoleCursorPosition(StdOut,coord);
    printf("%s", remove ? "��" : "��");
	coord.X = 0;
	coord.Y = Row * 2 + 1/* + result * (2 * num + 1)*/;
	SetConsoleCursorPosition(StdOut,coord);
    printf("%i\r", result);
}

void ReMove(const unsigned &Y,const unsigned &X,const unsigned &Row)
{
	Move(Y,X,Row,1);
}

void Trial(unsigned Line,	    			//��ǰ����
		   unsigned Row,					//����/����
		   bool **q,						//Map
		   bool *diagonalP,					//���Խ���
		   bool *diagonalN,					//���Խ���
		   bool *Col)						//��
{
	if (Line == Row)
	{
//		GenerateChart(Row);
//		fprintf(out,"--------------------------\n");
		for (unsigned i = 0;i != num;++i)
		{
			for (unsigned j = 0;j != num;++j)
            {        
//                fprintf(out,"%d  ",q[i][j]);
//                printf("%d  ",q[i][j]);
//                fprintf(out,"\n");
//                printf("\n");
                if (q[i][j] == 1)
                    Move(i + 1,j + 1,Row);
            }
		}
		++re;
//		fprintf(out,"\n");
//		printf("%d\n",re);
//		char Title[11] = "";
//		itoa(re,Title,10);
//		SetConsoleTitle(Title);

//		printf("Total: %d",re);
		Sleep(100);

        for (unsigned i = 0;i != num;++i)
			for (unsigned j = 0;j != num;++j)
				if (q[i][j] == 1)
					ReMove(i + 1,j + 1,Row);

//		system("cls");
		++result;
	}
	else
	{
		for (unsigned Column = 0;Column != Row;++Column)
		{
			if (diagonalP[num-Line+Column] == 0 &&
				diagonalN[Line+Column] == 0 &&
				Col[Column] == 0)
			{
				diagonalP[num-Line+Column] = 1;
				diagonalN[Line+Column] = 1;
				Col[Column] = 1;
				q[Line][Column] = 1;
				Trial(Line + 1,Row,q,diagonalP,diagonalN,Col);
				diagonalP[num-Line+Column] = diagonalN[Line+Column] = Col[Column] = 0;
				q[Line][Column] = 0;
			}
		}
	}
}

ForceInline Void main2(Int argc, Char **argv)
{
//	scanf("%d",&num);
	if (!num) return;
	bool *diagonalP = new bool[num * 2 - 1],
		 *diagonalN = new bool[num * 2 - 1],
		 *Col = new bool[num],
		 **q = new bool *[num];
	for (unsigned ix = 0;ix != num;++ix)
	{
		q[ix] = new bool[num];
		for (unsigned index = 0;index != num;++index)
			q[ix][index] = 0;
		Col[ix] = diagonalN[ix] = diagonalP[ix] =0;
	}
	for (unsigned ix = num;ix != num * 2 - 1;++ix)
		diagonalN[ix] = diagonalP[ix] = 0;

//    out = fopen("a.txt","wb");
 	GenerateChart(num);
	Trial(0,num,q,diagonalP,diagonalN,Col);
	printf("num=%d,result=%d\n",re,result);
	system("pause>NUL");
    delete diagonalN;
    delete diagonalP;
    delete Col;
    for (unsigned ix = 0;ix != num;++ix)
		delete q[ix];
    delete q;
}

#else

#define N 8        /* ���̱߳�  */
#define XXN     15 /* ���������Խ��߸��� */
#define TRUE 1
#define FALSE 0 
int map[N][N];/* ����     */ 
int col[N];   /* ��       */
int XX[XXN];  /* ���Խ��� */
int YY[XXN];  /* ���Խ��� */
FILE* fp;
int num=0;  /* ��ĸ��� */

			/**
			��ʾһ����
*/
void GenerateChart(const unsigned &Row)
{
	if (!Row) return;
	HANDLE StdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	PChar begin,end,separator;
	COORD coord;
	coord.X = 0;
	coord.Y = 0;
//	SetConsoleCursorPosition(StdOut,coord);
	for (unsigned c,r = 0;r != Row * 2 + 1;++r)
	{
		c = 1;
		if (r % 2 == 0)
			if (r == 0)
            {
                begin = "��";
                separator = "����";
                end = "����";
            }
			else if (r == Row * 2)
            {
                begin = "��";
                separator = "����";
                end = "����";
            }
			else
            {
                begin = "��";
                separator = "����";
                end = "����";
            }
			else
            {
                begin = "��";
                separator = "����";
                end = "����";
            }

			printf("%s",begin);
			while (c++ != Row)
				printf("%s",separator);
			printf("%s\t\n",end,r);
	}
}

void Move(const unsigned &Y,
		  const unsigned &X,
		  const unsigned &Row,
		  const bool &remove = 0)
{
	HANDLE StdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD coord;
	coord.X = (X * 2 -1) * 2;
	coord.Y = Y * 2 - 1 + num * (2 * N + 1);
	SetConsoleCursorPosition(StdOut,coord);
	if (remove)
		printf("��");
	else
		printf("��");
	coord.X = 0;
	coord.Y = Row * 2 + 1 + num * (2 * N + 1);
	SetConsoleCursorPosition(StdOut,coord);
}

void ReMove(const unsigned &Y,const unsigned &X,const unsigned &Row)
{
	Move(Y,X,Row,1);
}

void showMap()
{
	
	int i,j;
	GenerateChart(N);
//	printf("\n--------------------------\n");
	for(i=0;i<N;i++){
		for(j=0;j<N;j++)
			if (map[i][j])
				Move(i+1,j+1,N);
//			printf("%-3d",map[i][j]);
//		printf("\n");
	}
}

/**
�ݹ���⺯��
*/
int  trya(int y)
{
	int i;
	int success=FALSE;
	if( y==N){  /* ���һ����*/
//		showMap();
//		Sleep(1000);
		num++;
		return TRUE;
	}
	for(i=0;i<N;i++){
		if(XX[N-y+i]==0 && YY[i+y]==0 && col[i]==0) /* ��֤����Ҫ�� �Խ��ߣ��У�û���ظ��������� */
		{ 
			
			XX[N-y+i]=YY[i+y]=col[i]=map[y][i]=1; 
			if(trya(y+1)) success=TRUE;              /* ����һ���ʺ�  */   
			XX[N-y+i]=YY[i+y]=col[i]=map[y][i]=0;
		}
		
	}
	return success;
}

ForceInline Void main2(Int argc, Char **argv)
{
	int i,j;
	
//	fp=fopen("queen8.txt","w+");
	for(i=0;i<N;i++)
		for(j=0;j<N;j++)
			map[i][j]=0;
		for(i=0;i<XXN;i++) XX[i]=YY[i]=0;
		
//		printf("\n start..............");
		if(!trya(0))printf("\n no resolution!");
		printf("\nnum=%d\n",num);
}

#endif

void __cdecl main(Int argc, Char **argv)
{
    getargs(&argc, &argv);
    main2(argc, argv);
    exit(0);
}
