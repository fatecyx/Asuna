#pragma comment(linker,"/ENTRY:main")
#pragma comment(linker,"/MERGE:.text=.Kaede /SECTION:.Kaede,ERW")
#pragma comment(linker,"/MERGE:.rdata=.Kaede")
#pragma comment(linker,"/MERGE:.data=.Kaede")
#pragma comment(lib, "ucidec.lib")

#include "BMP2G00.H"
#include <stdio.h>
#include <conio.h>
#include "getmainargs.h"
#include "my_crtadd.h"
#include "../TA.h"

void FORCEINLINE main2(int argc, char **argv)
{
    FILE *fp;
    int  srclen, w, h, b, stride;
    char *pDecoded, *pBuffer, *pRegion, szOutFile[MAX_PATH];
    char *pExt;
    TBitMapHeader header = { 'MB', 0, 0, 0x36, {0x28, 0, 0, 1, 0} };

    for (int i = 1; i != argc; ++i)
    {
        fp = fopen(argv[i], "rb");
        if (fp == NULL)
            continue;

        srclen = fsize(fp);
        pBuffer = (char *)malloc(srclen);
        fread(pBuffer, srclen, 1, fp);
        fclose(fp);

        G00 g;

        header = *(TBitMapHeader *)pBuffer;
        pDecoded = pBuffer + header.dwRawOffset;
        g.Open(pDecoded, &header, srclen);
        pExt = findext(argv[i]);
        if (pExt)
            *pExt = 0;
        sprintf(szOutFile, "%s.rgn", argv[i]);
        fp = fopen(szOutFile, "rb");
        if (fp)
        {
            srclen = fsize(fp);
            pRegion = (char *)malloc(srclen);
            fread(pRegion, srclen, 1, fp);
            fclose(fp);
            g.SetRegionInfo((TMyRegion *)pRegion, srclen);
            free(pRegion);
        }
        sprintf(szOutFile, "%s.g00", argv[i]);
        if (pExt)
            *pExt = '.';
        g.ConvertToG00(szOutFile);

        free(pBuffer);
    }
}

void __cdecl main(int argc, char **argv)
{
    getargs(&argc, &argv);
    main2(argc, argv);
    exit(0);
}