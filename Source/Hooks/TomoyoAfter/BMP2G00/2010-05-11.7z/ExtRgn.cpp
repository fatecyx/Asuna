#pragma comment(linker,"/ENTRY:main")
#pragma comment(linker,"/MERGE:.text=.Kaede /SECTION:.Kaede,ERW")
#pragma comment(linker,"/MERGE:.rdata=.Kaede")
#pragma comment(linker,"/MERGE:.data=.Kaede")

#include <Windows.h>
#include <stdio.h>
#include "getmainargs.h"
#include "BMP2G00.H"

void FORCEINLINE main2(int argc, char **argv)
{
    FILE *fp, *fOut;
    char szFile[MAX_PATH];
    char *pExtension, *pBackLash;
    TRegion Region;
    TMyRegion MyRegion;
    TG00Header_2 h;

    for (int i = 1; i != argc; ++i)
    {
        fp = fopen(argv[i], "rb");
        if (fp == NULL)
            continue;

        if (fread(&h, 9, 1, fp) != 1 || h.id != 2)
        {
            fclose(fp);
            continue;
        }

        if (h.uiRegionCount == 1)
        {
            if (fread(&Region, sizeof(Region), 1, fp) == 1)
            {
                if (Region.rcRegion.right + 1 == (uint_32)h.usWidth &&
                    Region.rcRegion.bottom + 1 == (uint_32)h.usHeight &&
                    Region.uiOriginX == 0 && Region.uiOriginY == 0)
                {
                    fclose(fp);
                    continue;
                }
            }
            else
            {
                fclose(fp);
                continue;
            }
            fseek(fp, -(long)sizeof(Region), SEEK_CUR);
        }

        pExtension = strrchr(argv[i], '.');
        if (pExtension)
        {
            pBackLash = strrchr(argv[i], '\\');
            if (pBackLash < pExtension)
            {
                *pExtension = 0;
            }
        }
        sprintf(szFile, "%s.rgn", argv[i]);
        if (pExtension && *pExtension == 0)
        {
            *pExtension = '.';
        }

        fOut = fopen(szFile, "wb");
        if (fOut == NULL)
        {
            fclose(fp);
            continue;
        }

        while (h.uiRegionCount--)
        {
            if (fread(&Region, sizeof(Region), 1, fp) != 1)
                break;

            if (Region.rcRegion.left == 0 && 
                Region.rcRegion.top == 0 &&
                Region.rcRegion.right == 0 && 
                Region.rcRegion.bottom == 0)
                continue;

            MyRegion.usLeft   = (uint_16)Region.rcRegion.left;
            MyRegion.usTop    = (uint_16)Region.rcRegion.top;
            MyRegion.usRight  = (uint_16)Region.rcRegion.right;
            MyRegion.usBottom = (uint_16)Region.rcRegion.bottom;
            MyRegion.uiOriginX  = Region.uiOriginX;
            MyRegion.uiOriginY  = Region.uiOriginY;

            fwrite(&MyRegion, sizeof(MyRegion), 1, fOut);
        }

        fclose(fp);
        fclose(fOut);
    }
}

void __cdecl main(int argc, char **argv)
{
    getargs(&argc, &argv);
    main2(argc, argv);
    exit(0);
}